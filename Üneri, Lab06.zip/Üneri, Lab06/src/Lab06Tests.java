import java.util.ArrayList;

/**
 * Tests the methods at the bottom of the class.
 * @author Alp �neri
 * @version 29.4.19
 */ 
public class Lab06Tests
{
   public static void main( String[] args)
   {
      // constants
      final String stringTest = "\"echochamber\"";
      final int decTest = 0;
      final int digitNumTest = 3;
      
      // variables
      ArrayList<String> stringsTest = new ArrayList<String>();
      
      // test getCharNum
      System.out.println( stringTest + " contains " + getCharNum( stringTest, 'e') + " 'e' characters.\n");
      
      // test decToBin
      System.out.print( decTest + " to binary: ");
      decToBin( decTest);
      System.out.println( "\n");
      
      // initialize stringsTest
      stringsTest.add( "delta");
      stringsTest.add( "bravo");
      stringsTest.add( "charlie");
      
      // test inLexiOrder
      System.out.println( "Collection is in lexicographic order: " + inLexiOrder( stringsTest) + "\n");
      
      // test printIncreasingEvens
      printIncreasingEvens( digitNumTest);
   }
   
   // methods
   
   /**
    * Returns the number of times a character appears within a String.
    * @param s The String to be searched for the character.
    * @param c The character to be searched within the String.
    * @return The number of times the character appears within the String.
    */ 
   public static int getCharNum( String s, char c) 
   {
      if (s.length() == 0) 
      {
         return 0;
      }
      
      int count = 0;
      
      if ( s.substring( 0, 1).equals( c + ""))
      {
         count = 1;
      }
      
      return count + getCharNum( s.substring( 1), c);
   }
   
   /**
    * Prints the int value given in decimal in binary.
    * @param i The int value given in decimal to be converted to binary.
    */ 
   public static void decToBin( int i) 
   {
      if ( i == 0)
      {
         System.out.print( 0 + " ");
      }
      else if ( i > 0) 
      {
         decToBin( i / 2);
         
         System.out.print( i % 2 + " ");
      }
   }
   
   /**
    * Returns true if the given collection of Strings is in lexicographic order, false if not.
    * @param strings The collection of Strings to be checked.
    * @param c The index within the collection to start from.
    * @return True if the given collection of Strings is in lexicographic order, false if not.
    */ 
   public static boolean inLexiOrder( ArrayList<String> strings, int i)
   {
      if ( i >= strings.size())
      {
         return true;
      }
      else if ( strings.get(i - 1).compareToIgnoreCase( strings.get(i)) < 0)
      {
         return inLexiOrder( strings, i + 1);
      }
      else
      {
         return false;
      }
   }
   
   /**
    * Returns true if the given collection of Strings is in lexicographic order, false if not.
    * @param strings The collection of Strings to be checked.
    * @return True if the given collection of Strings is in lexicographic order, false if not.
    */ 
   public static boolean inLexiOrder( ArrayList<String> strings)
   {
      return inLexiOrder( strings, 1);
   }
   
   /**
    * Checks whether the given int has its digits in increasing order.
    * @param i The int to be checked.
    * @return True if the given int has its digits in increasing order, false if not.
    */ 
   public static boolean critCheck( int i)
   {
      boolean result = true;
      String iString = i + "";
      
      for ( int j = 0; j < iString.length() - 1; j++)
      {
         if ( Character.getNumericValue( iString.charAt(j)) < Character.getNumericValue( iString.charAt(j + 1)))
         {
            result = result && true;
         }
         else
         {
            result = result && false;
         }
      }
      return result;
   }
   
   /**
    * Calculates the current and limit values for the given digit number, prints all even numbers that meet the criteria.
    * @param digitNum The number of digits from which the current and limit values will be calculated.
    */ 
   public static void printIncreasingEvens( int digitNum)
   {
      printIncreasingEvens( ((int) Math.pow( 10, digitNum - 1)), ((int) Math.pow( 10, digitNum)));
   }
   
   /**
    * Prints all even numbers between current and limit that meet the criteria.
    * @param current The Current number to be tested.
    * @param limit The greatest number to be tested.
    */ 
   public static void printIncreasingEvens( int current, int limit)
   {
      if ( critCheck( current))
      {
         System.out.print( current + " ");
      }
      
      if ( current < limit)
      {
         printIncreasingEvens( current + 2, limit);
      }
   }
}