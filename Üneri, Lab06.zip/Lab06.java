import java.util.Scanner;

/**
 * Writing static methods
 * @author Alp �neri
 * @version 15.11.18
 */ 
public class Lab06
{
   /**
   * Takes a base double and an int power, returns the base raised to the power.
   * @param x The base number (double)
   * @param y The power (int)
   * @return The base raised to the power (double)
   */
   public static double power( double x, int y)
   {
      double n;
      n = 1;
      while ( y > 0)
      {
         n =  n * x;
         y = y - 1;
      }
      return n;
   }
   
   /**
   * Takes a number and returns its factorial.
   * @param n The number whose factorial will be computed (double)
   * @return The factorial of the number entered (double)
   */
   public static double factorial( int n)
   {
      double factorial;
      factorial = 1;
      for ( int i = n; i > 1; i--)
         factorial = factorial * i;
      return factorial;
   }
   
   /**
   * Takes a string and returns it reversed.
   * @param s The string to be reversed (String)
   * @return The string reversed (String)
   */
   public static String reverse( String s)
   {
      int sLength;
      String s1;
      s1 = "";
      sLength = s.length();
      for ( int i = sLength - 1; i >= 0; i--)
         s1 = s1 + s.charAt( i);
      return s1;
   }
   
   /**
   * Takes a binary as a string and returns its decimal value.
   * @param base2 The binary number to be converted into binary (String)
   * @return The binary number in decimal (int)
   */
   public static int toDecimal( String base2)
   {
      int decimal = 0;
      int remainder = 0;
      int multiplier = 1;
      int base2Int;
      base2Int = Integer.valueOf( base2);
      while ( base2Int > 0)
      {
         remainder = base2Int % 10;
         base2Int = base2Int / 10;
         decimal = decimal + remainder * multiplier;
         multiplier = multiplier * 2;
      }
      return decimal;
   }
   
   /**
   * Takes a decimal integer and returns its binary equivalent.
   * @param decimal The decimal number to be converted to binary (int)
   * @return The decimal number in binary (String)
   */
   public static String toBinary ( int decimal)
   {
      int binary = 0;
      int remainder = 0;
      int multiplier = 1;
      while ( decimal > 0)
      {
         remainder = decimal % 2;
         decimal = decimal / 2;
         binary = binary + remainder * multiplier;
         multiplier = multiplier * 10;
      }
      return Integer.toString( binary);
   }
   
   /**
   * Takes a double and the number of terms, returns the sin of the double computed to the number of terms.
   * @param x The number whose sine will be computed (double)
   * @param y The number of terms of series to be used (double)
   * @return The sine of the first number entered computed using the number of terms entered
   */
   public static double sin ( double x, double y)
   {
      double term;
      double sinTest;
      int factorial;
      
      sinTest = x;
      term = x;
      factorial = 1;
      
      for ( int n = 0; n <= y; n++)
      {
         term = term * power( x, 2) * -1 / ( ( factorial + 1) * ( factorial + 2));
         factorial = factorial + 2;
         sinTest = sinTest + term;
      }
      
      return sinTest;
   }
   
   //main method
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants
      
      final int SPACES = 10;
      final int SPACES1 = 20;
      final int SPACES2 = 24;

      // variables
      
      int n;
      int i;
      double x;
      String binary1;
      String binary2;
      int decimal1;
      int decimal2;
      int decimalSum;
      String binaryResult;
      int responseLength;
      String word;
      char wordDeterminer;
      String wordDeterminerString;
      double x1;
      double x2;
      double x3;
      double y;
      String x1String;
      int x1Length;
      String x2String;
      int x2Length;
      String x3String;
      int x3Length;
      double term;
      String termString;
      int termLength;
      double sinTest;
      String sinTestString;
      int sinTestLength;
      String nString;
      int nLength;
      String n2String;
      int n2Length;
      String n3String;
      int n3Length;
      String n4String;
      int n4Length;
      String nFacString;
      int nFacLength;
      String response;

      // program code
      System.out.println( "Start...");
      
      //formatting
      System.out.println();
      
      //first task
      System.out.println( "First task");
      for ( n = -1; n <= 10; n++)
      {
         //converting the int to be printed into a string so its length can be measured
         nString = Integer.toString( n);
         nLength = nString.length();
         
         //printing the spaces for formatting
         for ( i = 0; i + nLength < SPACES; i++)
            System.out.print( " ");
         
         //printing the first column
         System.out.print( n);
         
         //converting the int to be printed into a string so its length can be measured
         n2String = Double.toString( power( n, 2));
         n2Length = n2String.length();
         
         //printing the spaces for formatting
         for ( i = 0; i + n2Length < SPACES; i++)
            System.out.print( " ");
         
         //printing the second column
         System.out.print( power( n, 2));
         
         //converting the int to be printed into a string so its length can be measured
         n3String = Double.toString( power( n, 3));
         n3Length = n3String.length();
         
         //printing the spaces for formatting
         for ( i = 0; i + n3Length < SPACES; i++)
            System.out.print( " ");
         
         //printing the third column
         System.out.print( power( n, 3));
         
         //converting the int to be printed into a string so its length can be measured
         n4String = Double.toString( power( n, 4));
         n4Length = n4String.length();
         
         //printing the spaces for formatting
         for ( i = 0; i + n4Length < SPACES; i++)
            System.out.print( " ");
         
         //printing the fourth column
         System.out.print( power( n, 4));
         
         //moving to the next line for formatting
         System.out.println();
      }

      //formatting
      System.out.println();
      
      //second task
      System.out.println( "Second task");
      for ( n = 1; n <= 15; n++)
      {
         //converting the int to be printed into a string so its length can be measured
         nString = Integer.toString( n);
         nLength = nString.length();
         
         //printing the spaces for formatting
         for ( i = 0; i + nLength < SPACES1; i++)
            System.out.print( " ");
         
         //printing the first column
         System.out.print( n);
         
         //converting the int to be printed into a string so its length can be measured
         nFacString = Double.toString( factorial( n));
         nFacLength = nFacString.length();
         
         //printing the spaces for formatting
         for ( i = 0; i + nFacLength < SPACES1; i++)
            System.out.print( " ");
         
         //printing the second column
         System.out.print( factorial( n));
         
         //moving to the next line for formatting
         System.out.println();
      }
      
      //formatting
      System.out.println();
      
      //third task
      System.out.println( "Third task");
      
      //getting the two binary values from the user
      System.out.print( "Please enter the first binary number.");
      binary1 = scan.next();
      System.out.print( "Please enter the second binary number.");
      binary2 = scan.next();
      
      //turning the binary numbers into decimals and printing them out
      decimal1 = toDecimal( binary1);
      System.out.println( "The first binary number in decimal is " + decimal1 + ".");
      decimal2 = toDecimal( binary2);
      System.out.println( "The second binary number in decimal is " + decimal2 + ".");
      
      //adding them up and printing the sum out
      decimalSum = decimal1 + decimal2;
      System.out.println( "The two decimals added up is " + decimalSum + ".");
      
      //turning decimalSum to binary and printing it out
      binaryResult = toBinary( decimalSum);
      System.out.println( "The two binary numbers added together is " + binaryResult + ".");
      
      //formatting
      System.out.println();
      
      //fourth task
      System.out.println( "Fourth task");
      
      //getting the string to be reversed from the user
      System.out.print( "Please enter the line you wish reversed.");
      response = scan.nextLine();
      response = scan.nextLine();
      
      //setting the variables to the appropriate value
      responseLength = response.length();
      word = "";
      
      System.out.print( "The string reversed is ");
      for ( i = 0; i < responseLength; i++)
      {
         //looking at the chars encountered one by one and turning them to strings so the method .equals can be used
         wordDeterminer = response.charAt( i);
         wordDeterminerString = Character.toString( wordDeterminer);
         
         //the char encountered is added to a string until a space is encountered
         if ( wordDeterminerString.equals( " "))
         {
            System.out.print( reverse( word) + " ");
            word = "";
         }
         else
            word = word + wordDeterminer;
      }
      
      //printing the last word which does not have a space after it
      System.out.print( reverse( word));
      
      //formatting
      System.out.println();
      System.out.println();
      
      //fifth task
      System.out.println( "Fifth task");
      
      //getting the number of terms and the value from the user
      System.out.print( "Please enter the number of terms you wish to compute the series to.");
      x = scan.nextInt();
      System.out.print( "Please enter the number whose sine will be computed.");
      y = scan.nextDouble();
      
      //setting sinTest to the appropriate value
      sinTest = 0;
      
      for ( n = 0; n <= x; n++)
      {
         
         //converting the int to be printed into a string so its length can be measured
         nString = Double.toString( n);
         nLength = nString.length();
         
         //printing the spaces for formatting
         for ( i = 0; i + nLength < SPACES2; i++)
            System.out.print( " ");
         
         //printing the first column
         System.out.print( n);
         
         //getting the operation into a memory location so the code doesn't get more confusing
         x1 = power( -1, n);
         
         //converting the int to be printed into a string so its length can be measured
         x1String = Double.toString( x1);
         x1Length = x1String.length();
         
         //printing the spaces for formatting
         for ( i = 0; i + x1Length < SPACES2; i++)
            System.out.print( " ");
         
         //printing the second column
         System.out.print( x1);
         
         //getting the operation into a memory location so the code doesn't get more confusing
         x2 = Math.pow( y, ( 2 * n + 1));
         
         //converting the int to be printed into a string so its length can be measured
         x2String = Double.toString( x2);
         x2Length = x2String.length();
         
         //printing the spaces for formatting
         for ( i = 0; i + x2Length < SPACES2; i++)
            System.out.print( " ");
         
         //printing the third column
         System.out.print( x2);
         
         //getting the operation into a memory location so the code doesn't get more confusing
         x3 = factorial( ( 2 * n + 1));
         
         //converting the int to be printed into a string so its length can be measured
         x3String = Double.toString( x3);
         x3Length = x3String.length();
         
         //printing the spaces for formatting
         for ( i = 0; i + x3Length < SPACES2; i++)
            System.out.print( " ");
         
         //printing the fourth column
         System.out.print( x3);
         
         //getting the operation into a memory location so the code doesn't get more confusing
         term = x1 * x2 / x3;
         
         //converting the int to be printed into a string so its length can be measured
         termString = Double.toString( term);
         termLength = termString.length();
         
         //printing the spaces for formatting
         for ( i = 0; i + termLength < SPACES2; i++)
            System.out.print( " ");
         
         //printing the fifth column
         System.out.print( term);
         
         //getting the operation into a memory location so the code doesn't get more confusing
         sinTest = sinTest + term;
         
         //converting the int to be printed into a string so its length can be measured
         sinTestString = Double.toString( sinTest);
         sinTestLength = sinTestString.length();
         
         //printing the spaces for formatting
         for ( i = 0; i + sinTestLength < SPACES2; i++)
            System.out.print( " ");
         
         //printing the sixth column
         System.out.print( sinTest);
         
         //moving to the next line for formatting
         System.out.println();
      }
      
      //formatting
      System.out.println();
      
      //sixth task
      System.out.println( "Sixth task");
      System.out.println( "sin(" + y + ") computed using Math.sin is " + Math.sin( y));
      System.out.println( "sin(" + y + ") computed using the series with " + x + " terms is " + sin( y, x));
      
      //formatting
      System.out.println();
      
      System.out.println( "End.");
   }

}