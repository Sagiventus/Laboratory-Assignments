import java.util.Scanner;

/**
 * __program description___ 
 * @author Alp �neri
 * @version 18.10.18
 */ 
public class lab02a
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables

      // program code
      System.out.println( "Start...");


      System.out.println( "End.");
   }

}