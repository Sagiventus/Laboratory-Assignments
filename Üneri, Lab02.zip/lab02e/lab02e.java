import java.util.Scanner;

/**
 * Inputs name, age, salary, and comment, outputs website 
 * @author Alp �neri
 * @version 18.10.18
 */ 
public class lab02e
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants
      
      final String tag1 = "<!DOCTYPE html>";
      final String tag2 = "<html>";
      final String tag3 = "<head>";
      final String tag4 = "<title>";
      final String tag5 = "<hr>";
      final String tag6 = "<h1>";
      final String tag7 = "<p>";
      final String tag8 = "<body>";
      
      // variables
      
      String name;
      int age;
      double salary;
      String comment;

      // program code
      //System.out.println( "Start...");
      
      //System.out.println( "Please enter the employee's name.");
      name = scan.nextLine();
      
      //System.out.println( "Please enter the employee's age.");
      age = scan.nextInt();
      
      //System.out.println( "Please enter the employee's salary.");
      salary = scan.nextDouble();
      
      //System.out.println( "Please enter the employee's comment.");
      scan.nextLine();
      comment = scan.nextLine();
      
      System.out.println( tag1 + tag2 +  tag3 +  tag4 + name + "'s Home Page</title> </head>" + tag8 +  tag5 + tag6 + name + "</h1>" +  tag7 + "Age: " + age + "</p>" + tag7 + "Salary: " + salary + "</p>" + tag7 + "Comments: " + comment + "</p>" + tag5+  "</body> </html>");


      //System.out.println( "End.");
   }

}