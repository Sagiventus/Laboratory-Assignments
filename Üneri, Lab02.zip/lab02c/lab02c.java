import java.util.Scanner;

/**
 * Input two numbers, outputs their sum, difference, product, division, and modulus. 
 * @author Alp �neri
 * @version 18.10.18
 */ 
public class lab02c
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      
      double number1;
      double number2;
      
      double sum;
      double difference;
      double product;
      double division;
      double modulus;

      // program code
      System.out.println( "Start...");
      
      System.out.print( "Please enter the first number.");
      number1 = scan.nextDouble();
      
      System.out.print( "Please enter the second number.");
      number2 = scan.nextDouble();
      
      sum = number1 + number2;
      difference = number1 - number2;
      product = number1 * number2;
      division = number1 / number2;
      modulus = number1 % number2;
         
      System.out.println( "The sum of the two numbers is " + sum);
      System.out.println( "The difference of the two numbers is " + difference);
      System.out.println( "The product of the two numbers is " + product);
      System.out.println( "The division of the two numbers is " + division);
      System.out.println( "The modulus of the two numbers is " + modulus);
      System.out.println( "The bigger number is " + Math.max (number1, number2));
      System.out.println( "The smaller number is " + Math.min (number1, number2));


      System.out.println( "End.");
   }

}