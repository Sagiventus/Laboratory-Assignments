import java.util.Scanner;
import java.util.ArrayList;
import cs1.SimpleURLReader;
import readers.*;

/**
 * Menu-driven program that test the URLReader classes. 
 * @author Alp �neri
 * @version 3.3.19
 */ 
public class MenuTestURLReaders
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      ArrayList<MySimpleURLReader> readers;
      boolean flag;
      boolean back;
      boolean duplicate;
      int response;
      int response1;
      int i;
      String urlResponse;
      MySimpleURLReader reader;

      // program code
      System.out.println( "Start...");
      
      //initialize the variables
      readers = new ArrayList<MySimpleURLReader>();
      flag = true;
      i = 0;
      
      do
      {
         //main interface
         System.out.println( "Please select a task to perform: ");
         System.out.println( "1: Enter the url of the poem to add to the collection.");
         System.out.println( "2: List all poems in the collection.");
         System.out.println( "3: Quit.");
         System.out.print( "Awaiting input: ");
         response = scan.nextInt();
         
         //add url operator
         if ( response == 1)
         {
            System.out.print( "Please enter the url of the poem to add to the collection: ");
            urlResponse = scan.nextLine();
            urlResponse = scan.nextLine();
            
            duplicate = false;
            
            for ( i = 0; i < readers.size(); i++)
            {
               if ( readers.get(i).getURL().equals( urlResponse))
               {
                  duplicate = true;
               }
            }
            
            if ( !duplicate)
            {
               if ( urlResponse.contains( "txt"))
               {
                  reader = new MySimpleURLReader( urlResponse);
                  
                  readers.add( reader);
                  
                  System.out.println( "Poem successfully added to collection.");
               }
               else if ( urlResponse.contains( "htm"))
               {
                  reader = new HTMLFilteredReader( urlResponse);
                  
                  readers.add( reader);
                  
                  System.out.println( "Poem successfully added to collection.");
               }
               else
               {
                  System.out.println( "Invalid URL!");
               }
            }
            else
            {
               System.out.println( "Duplicate URL!");
            }
         }
         
         //list poems operator
         else if ( response == 2)
         {
            do
            {
               back = false;
               if ( readers.size() > 0)
               {
                  System.out.println( "The current collection of poems include: ");
                  
                  for ( i = 0; i < readers.size(); i++)
                  {
                     System.out.println( "The poem " + readers.get(i).getName() 
                                           + " at index number: " + i);
                  }
                  
                  System.out.println( "Back: " + ( i));
               }
               else
               {
                  System.out.println( "No poems in collection!");
                  back = true;
               }
               
               if ( !back)
               {
                  System.out.print( "Please select a task to perform: ");
                  response1 = scan.nextInt();
                  
                  if ( response1 == i)
                  {
                     back = true;
                  }
                  else if ( response1 < i)
                  {
                     System.out.println( readers.get( response1).getPageContents());
                  }
                  else 
                  {
                     System.out.println( "Invalid input!");
                  }
               }
               
            } while ( !back);
         }
         
         //quit operator
         else if ( response == 3)
         {
            flag = false;
         }
         
         //invalid input operator
         else
         {
            System.out.println( "Invalid input!");
         }
         
      } while ( flag);

      System.out.println( "End.");
   }

}