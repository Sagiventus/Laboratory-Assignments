import cs1.SimpleURLReader;
import readers.*;

/**
 * Tests the SimpleURLReader class.
 * @author Alp �neri
 * @version 3.3.19
 */ 
public class TestSimpleURLReader
{
   public static void main( String[] args)
   {
      // constants
      final String URL = "http://www.cs.bilkent.edu.tr/~david/housman.txt";
      final String HTML_URL = "http://www.cs.bilkent.edu.tr/~david/housman.htm";
      final String XHTML_URL = "http://www.cs.bilkent.edu.tr/~david/index.html";
      
      // variables
      SimpleURLReader reader;
      MySimpleURLReader myReader;
      HTMLFilteredReader htmlReader;
      XHTMLFilteredReader xhtmlReader;

      // program code
      System.out.println( "Start...");
      
      //initialize the variables
      reader = new SimpleURLReader( URL);
      myReader = new MySimpleURLReader( URL);
      htmlReader = new HTMLFilteredReader( HTML_URL);
      xhtmlReader = new XHTMLFilteredReader( XHTML_URL);
      
      //test SimpleURLReader
      System.out.println( "Testing SimpleURLReader:");
      
      System.out.println( "The page has contents:");
      System.out.println( reader.getPageContents());
      
      System.out.println( "The page has the following number of lines: " + reader.getLineCount());

      //formatting
      System.out.println();
      
      //test MySimpleURLReader
      System.out.println( "Testing MySimpleURLReader:");
      
      System.out.println( "The page has URL: " + myReader.getURL());
      
      //formatting
      System.out.println();
      
      System.out.println( "The page has name: " + myReader.getName());
      
      //formatting
      System.out.println();
      
      System.out.println( "The page has contents:");
      System.out.println( myReader.getPageContents());
      
      //test HTMLFilteredReader
      System.out.println( "Testing HTMLFilteredReader:");
      
      System.out.println( "The page has unfiltered contents:");
      System.out.println( htmlReader.getUnfilteredPageContents());
      
      System.out.println( "The page has filtered contents:");
      System.out.println( htmlReader.getPageContents());
      
      //test XHTMLFilteredReader
      System.out.println( "Testing XHTMLFilteredReader:");
      
      System.out.println( "The page has overhead: " + xhtmlReader.getOverhead());
      
      //formatting
      System.out.println();
      
      System.out.println( "The page has the following links: " + xhtmlReader.getLinks());
      
      //experiment with extended type checking mechanism
      myReader = new XHTMLFilteredReader( XHTML_URL);
      
      //formatting
      System.out.println();
      
      System.out.println( "Testing extended type checking mechanism: ");
      System.out.println( "myReader = new XHTMLFilteredReader( XHTML_URL)");
      
      //formatting
      System.out.println();
      
      System.out.println( "Testing ( (XHTMLFilteredReader) myReader).getOverhead()");
      
      //formatting
      System.out.println();
      
      System.out.println( "The page has overhead: " + ( (XHTMLFilteredReader) myReader).getOverhead());
      
      System.out.println( "End.");
   }

}