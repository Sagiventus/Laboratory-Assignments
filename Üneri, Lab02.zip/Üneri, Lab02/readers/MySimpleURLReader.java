package readers;
import cs1.SimpleURLReader;

/**
 * Adds two methods to SimpleURLReader and fixes a bug. 
 * @author Alp �neri
 * @version 3.3.19
 */ 
public class MySimpleURLReader extends SimpleURLReader 
{
   // properties
   private String url;

   // constructors
   
  /**
   * Creates a MySimpleURLReader object using the constructor of the super class.
   * @param s The URL of the site to be used when creating the reader object.
   */
   public MySimpleURLReader( String s)
   {
      super( s);
      url = s;
   }

   // methods
   
  /**
   * Returns the URL used when creating the object.
   * @return The URL used when creating the object.
   */ 
   public String getURL()
   {
      return this.url;
   }
   
  /**
   * Returns the name of the website.
   * @return The name of the website.
   */ 
   public String getName()
   {
      String name = "";
      int count = 0;
      String url2 = this.getURL();
      
      while ( url2.charAt( url2.length() - 1 - count) != '/')
         count++;
      
      for ( int i = url2.length() - 1; i > url2.length() - 1 - count; i--)
         name = Character.toString( url2.charAt(i)) + name;
      
      return name;
   }
   
  /**Fixes the null bug of super's getPageContents().
    * @return The page contents without the null bug.
    */ 
   @Override
   public String getPageContents()
   {
      String s = super.getPageContents();
      
      return s.substring( 4, s.length());
   }
   
}