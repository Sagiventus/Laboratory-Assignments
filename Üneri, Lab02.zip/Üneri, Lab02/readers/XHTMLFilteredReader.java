package readers;
import java.util.ArrayList;

/**
 * Adds two methods to the HTMLFilteredReader class. 
 * @author Alp �neri
 * @version 3.3.19
 */ 
public class XHTMLFilteredReader extends HTMLFilteredReader
{
   // constructors
   
  /**
   * Creates a XHTMLFilteredReader object using the constructor of the super class.
   * @param s The URL of the site to be used when creating the reader object.
   */
   public XHTMLFilteredReader( String s)
   {
      super( s);
   }
   
   // methods
   
  /**
   * Returns the number of characters without the html tags / the total number of characters.
   * @return The number of characters without the html tags / the total number of characters.
   */ 
   public String getOverhead()
   {
      int unfilteredLength = super.getUnfilteredPageContents().length();
      int filteredLength = super.getPageContents().length();
      return filteredLength + "/" + unfilteredLength ;
   }
   
  /**
   * Returns the links embedded within the site's source code.
   * @return The links embedded within the site's source code.
   */ 
   public ArrayList<String> getLinks()
   {
      ArrayList<String> links = new ArrayList<String>();
      String contents = super.getUnfilteredPageContents();
      String link = "";
      int beginningIndex;
      int endIndex;

      for ( int i = 0; i < contents.length() - 5; i++)
      {
         if ( contents.charAt(i) == 'h' && contents.charAt(i + 1) == 'r' && 
             contents.charAt(i + 2) == 'e' && contents.charAt(i + 3) == 'f' && 
             contents.charAt(i + 4) == '=' && contents.charAt(i + 5) == '"')
         {
            beginningIndex = i + 6;
            
            do
            {
               i++;
               
            } while ( contents.charAt(i + 6) != '"');
            
            endIndex = i + 6;
            
            link = contents.substring( beginningIndex, endIndex) + "\n";
            
            links.add( link);
         }
         
      }
      
      return links;
   }

}