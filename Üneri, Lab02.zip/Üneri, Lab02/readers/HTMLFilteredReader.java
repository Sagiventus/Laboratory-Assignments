package readers;

/**
 * Adds a method to the MySimpleURLReader class and overrides one. 
 * @author Alp �neri
 * @version 3.3.19
 */ 
public class HTMLFilteredReader extends MySimpleURLReader 
{
   // constructors
   
  /**
   * Creates an HTMLFilteredReader object using the constructor of the super class.
   * @param s The URL of the site to be used when creating the reader object.
   */
   public HTMLFilteredReader( String s)
   {
      super( s);
   }
   
   // methods
   
  /**
   * Gets the filtered page contents.
   * @return The page contents without the html tags.
   */ 
   @Override
   public String getPageContents()
   {
      String filteredContents = "";
      String unfilteredContents = this.getUnfilteredPageContents();
      
      for ( int i = 0; i < unfilteredContents.length(); i++)
      {
         if ( unfilteredContents.charAt(i) != '<')
         {
            filteredContents = filteredContents + unfilteredContents.charAt(i);
         }
         else
         {
            do
            {
               i++;
               
            } while ( unfilteredContents.charAt(i) != '>');
         }
      }
      return filteredContents;
   }
   
  /**
   * Gets the unfiltered page contents.
   * @return The unfiltered page contents.
   */ 
   public String getUnfilteredPageContents()
   {
      return super.getPageContents();
   }

}