import java.util.Scanner;

/**
 * A program that computes the maximum number of flowers that
 * can be planted in a triangular-shaped garden having sides 
 * of length a, b and c meters, assuming at most 17 flowers 
 * can be planted in each square meter.
 * @author Alp �neri
 * @version 18.10.18
 */ 
public class lab02d
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants
      
      final int flowerPerSquareMeter = 17;

      // variables
      
      double area;
      double semiPerimeter;
      int flower;
      double product;
         
      int side1;
      int side2;
      int side3;
         

      // program code
      System.out.println( "Start...");
      
      System.out.print( "Please enter the length of the first side of the triangle.");
      side1 = scan.nextInt();
      
      System.out.print( "Please enter the length of the second side of the triangle.");
      side2 = scan.nextInt();
      
      System.out.print( "Please enter the length of the third side of the triangle.");
      side3 = scan.nextInt();
      
      semiPerimeter = ( (side1 + side2 + side3)/2 );
      product = semiPerimeter * (semiPerimeter - side1) * (semiPerimeter - side2) * (semiPerimeter - side3); 
      area = Math.sqrt(product);
      flower = (int)(area * flowerPerSquareMeter );
      
      System.out.println( "The maximum number of flowers that can be planted in a triangular-shaped garden having sides of length " + side1 + ", " + side2 + ", and " + side3 + " meters, assuming that at most 17 flowers can be planted in each square meter is " + flower + " .");
      


      System.out.println( "End.");
   }

}