import java.util.Scanner;

/**
 * Computes PI three ways. 
 * @author Alp �neri
 * @version 08.11.2018
 */ 
public class Lab05d
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      
      int numberOfTerms;
      int numberOfTerms1;
      double piTest1;
      double term;
      double termSign;
      double termSignDeterminer;
      double termDenominator;
      double piTest2;
      double accuracy;

      // program code
      System.out.println( "Start...");
      
      //first task
      System.out.println( "Pi is equal to " + Math.PI + ".");
      
      //second task
      System.out.print( "Please enter the number of terms of the series you wish to compute.");
      numberOfTerms = scan.nextInt();
      numberOfTerms1 = numberOfTerms;
      
      //resetting values
      piTest1 = 0;
      term = 0;
      termSign = 1;
      termSignDeterminer = 0;
      termDenominator = 1;
      
      //loop for the second task
      while (numberOfTerms1 > 0)
      {
         if ( termSignDeterminer % 2 == 0)
            termSign = 1;
         else
            termSign = -1;
         
         term = termSign * 4 / termDenominator;
         termDenominator = termDenominator + 2;
         termSignDeterminer ++;
         piTest1 = piTest1 + term;
         numberOfTerms1 = numberOfTerms1 - 1;
      }
      
      System.out.println( "Pi computed using " + numberOfTerms + " number of terms is " +  piTest1 + ".");
      
      //third task
      System.out.print( "Please enter how accurate you want the result to be.");
      accuracy = scan.nextDouble();
      
      //resetting values
      piTest2 = 0;
      term = 0;
      termSign = 1;
      termSignDeterminer = 0;
      termDenominator = 1;
      
      //loop for the third task
      while ( Math.abs( piTest2 - Math.PI) > accuracy)
      {
         if ( termSignDeterminer % 2 == 0)
            termSign = 1;
         else
            termSign = -1;
         
         term = termSign * 4 / termDenominator;
         termDenominator = termDenominator + 2;
         termSignDeterminer ++;
         piTest2 = piTest2 + term;
      }
      
      System.out.println( "Pi computed with " + accuracy + " accuracy is " + piTest2 + ".");


      System.out.println( "End.");
   }

}