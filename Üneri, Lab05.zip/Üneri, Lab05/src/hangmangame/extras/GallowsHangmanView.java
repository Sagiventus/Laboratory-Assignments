package hangmangame.extras;
import javax.swing.*;
import java.awt.*;
import cs102.hangman.*;

/**
 * A more traditional view for Hangman.
 * @author Alp �neri
 * @version 15.4.19
 */ 
public class GallowsHangmanView extends JPanel implements IHangmanView 
{
   // properties
   HangmanModel hm;

   // constructors
   public GallowsHangmanView( HangmanModel hm)
   {
      this.hm = hm;
      setBackground( Color.CYAN);
   }
   
   // methods
   public void paintComponent( Graphics g)
   {
      super.paintComponent( g);
      
      ((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                          RenderingHints.VALUE_ANTIALIAS_ON);
      
      g.drawLine( 100, 375, 300, 375);
      g.drawLine( 200, 375, 200, 100);
      g.drawLine( 200, 100, 300, 100);
      g.drawLine( 300, 100, 300, 125);
      
      if ( hm.getNumOfIncorrectTries() >= 1)
      {
         g.drawOval( 275, 125, 50, 50);
      }
      
      if ( hm.getNumOfIncorrectTries() >= 2)
      {
         g.drawLine( 300, 175, 300, 275);
      }
      
      if ( hm.getNumOfIncorrectTries() >= 3)
      {
         g.drawLine( 300, 190, 340, 240);
      }
      
      if ( hm.getNumOfIncorrectTries() >= 4)
      {
         g.drawLine( 300, 190, 260, 240);
      }
      
      if ( hm.getNumOfIncorrectTries() >= 5)
      {
         g.drawLine( 300, 275, 340, 350);
      }
      
      if ( hm.getNumOfIncorrectTries() == 6)
      {
         g.drawLine( 300, 275, 260, 350);
      }
   }
   
   public void updateView( Hangman hm)
   {
      repaint();
   }

}