package hangmangame.extras;
import javax.swing.*;
import java.awt.event.*;
import cs102.hangman.*;

/**
 * Used to start a new Hangman game.
 * @author Alp �neri
 * @version 15.4.19
 */ 
public class NewGameButtonControl extends JButton implements IHangmanView
{
   // properties
   HangmanModel hm;
   HangmanLetterButtonControls bc;
   
   // constructors
   public NewGameButtonControl( HangmanModel hm, HangmanLetterButtonControls bc)
   {
      this.hm = hm;
      this.bc = bc;
      setText( "New Game");
      addActionListener( new NGActionListener());
      setEnabled( false);
   }
   
   // methods
   public void updateView( Hangman hm)
   {
      if ( hm.isGameOver())
      {
         setEnabled( true);
      }
   }
   
   public class NGActionListener implements ActionListener
   {
      public void actionPerformed( ActionEvent e)
      {
         setEnabled( false);
         bc.setEnabledAll( true);
         hm.initNewGame();
      }
   }
}