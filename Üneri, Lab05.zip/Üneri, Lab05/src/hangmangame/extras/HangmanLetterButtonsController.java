package hangmangame.extras;
import javax.swing.*;
import cs102.hangman.*;
import java.awt.event.*;

/**
 * ActionListener for LetterButtonsControls 
 * @author Alp �neri
 * @version 15.4.19
 */ 
public class HangmanLetterButtonsController implements ActionListener 
{
   // properties
   HangmanModel hm;
   
   // constructors
   public HangmanLetterButtonsController( HangmanModel hm)
   {
      this.hm = hm;
   }
   
   // methods
   public void actionPerformed( ActionEvent e)
   {
      JButton b;
      b = ((JButton) e.getSource());
      hm.tryThis( b.getText().charAt(0));
      b.setEnabled( false);
   }
}