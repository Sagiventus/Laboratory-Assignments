package hangmangame.extras;

import cs102.hangman.HangmanModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;

/**
 * Collection of UI components to form a complete Hangman game. 
 * View components implement IHangmanView, so they can automatically update
 * whenever the hangmanModel associated with changes, changes.
 * Other components are hangman controllers that update the model.
 * @author david
 */
public class HangmanGUIPanel extends JPanel {

   HangmanModel hm;
   
   public HangmanGUIPanel( HangmanModel hm) {
      this.hm = hm;
      setPreferredSize( new Dimension( 1200, 600) );
      setLayout( new BorderLayout() );

      // add controls and views here...
      TextFieldControlPanel tfCP = new TextFieldControlPanel( hm);
      add( tfCP, BorderLayout.NORTH);
      
      LabelsHangmanView labelsHMV = new LabelsHangmanView();
      add( labelsHMV, BorderLayout.WEST);
      hm.addView( labelsHMV);
      
      GallowsHangmanView gallowsHMV = new GallowsHangmanView( hm);
      add( gallowsHMV, BorderLayout.CENTER);
      hm.addView( gallowsHMV);
      
      HangmanLetterButtonControls lbC = new HangmanLetterButtonControls( hm);
      add( lbC, BorderLayout.EAST);
      hm.addView( lbC);
      
      NewGameButtonControl ngBC = new NewGameButtonControl( hm, lbC);
      add( ngBC, BorderLayout.SOUTH);
      hm.addView( ngBC);
   }
   
}
