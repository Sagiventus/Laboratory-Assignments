package hangmangame.extras;
import javax.swing.*;
import cs102.hangman.*;
import java.awt.event.*;
import java.awt.*;

/**
 * Used to try letters in Hangman.
 * @author Alp �neri
 * @version 15.4.19
 */ 
public class TextFieldControlPanel extends JPanel
{
   // properties
   Hangman hangman;
   JTextField tf;

   // constructors
   public TextFieldControlPanel( Hangman hangman)
   {
      this.hangman = hangman;
      tf = new JTextField();
      tf.setPreferredSize( new Dimension( 200, 50));
      setBackground( Color.GREEN);
      tf.addActionListener( new TFActionListener());
      add( tf);
   }
   
   public class TFActionListener implements ActionListener
   {
      public void actionPerformed( ActionEvent e)
      {
         String text = tf.getText();
         
         for ( int i = 0; i < text.length(); i++)
         {
            hangman.tryThis( text.charAt(i));
         }
         
         tf.setText( "");
      }
   }
}