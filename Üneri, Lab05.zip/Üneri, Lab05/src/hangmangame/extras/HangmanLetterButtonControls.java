package hangmangame.extras;
import cs102.hangman.*;

/**
 * Extends LetterButtonControls to specifically accomodate Hangman. 
 * @author Alp �neri
 * @version 15.4.19
 */ 
public class HangmanLetterButtonControls extends LetterButtonControls implements IHangmanView 
{
   // constructors
   public HangmanLetterButtonControls( HangmanModel hm)
   {
      super( hm.getAllLetters(), 13, 2, hm);
   }
   
   // methods
   public void updateView( Hangman hm)
   {
      setDisabled( hm.getUsedLetters());
      
      if ( hm.isGameOver())
      {
         setDisabled( hm.getAllLetters());
      }
   }
}