package hangmangame.extras;
import javax.swing.*;
import cs102.hangman.*;
import java.awt.*;

/**
 * Labels view for Hangman showing tries remaining, win/lose, and used letters. 
 * @author Alp �neri
 * @version 15.4.19
 */ 
public class LabelsHangmanView extends JPanel implements IHangmanView 
{
   // properties
   JLabel incorrectTriesLabel;
   JLabel wordLabel;
   JLabel usedLettersLabel;
   JLabel winLoseLabel;

   // constructors
   public LabelsHangmanView()
   {
      setLayout( new GridLayout( 4, 1));
      setPreferredSize( new Dimension( 200, 400));
      setBackground( Color.YELLOW);
      
      incorrectTriesLabel = new JLabel( "Tries Remaining: 6");
      wordLabel = new JLabel( "Word: ");
      usedLettersLabel = new JLabel( "Used Letters: ");
      winLoseLabel = new JLabel();
      
      add( incorrectTriesLabel);
      add( wordLabel);
      add( usedLettersLabel);
      add( winLoseLabel);
   }
   
   // methods
   public void updateView( Hangman hm)
   {
      incorrectTriesLabel.setText( "Tries Remaining: \n" + (6 - hm.getNumOfIncorrectTries()));
      wordLabel.setText( "Word: " + hm.getKnownSoFar());
      usedLettersLabel.setText( "Used Letters: " + hm.getUsedLetters());
      winLoseLabel.setText( "");
      
      if ( hm.isGameOver())
      {
         if ( hm.hasLost())
         {
            winLoseLabel.setText( "You LOSE!");
         }
         else
         {
            winLoseLabel.setText( "You WIN!");
         }
      }
   }
}