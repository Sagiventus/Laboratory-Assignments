import java.util.Scanner;

/**
 * Simple Calculator 
 * @author Alp �neri
 * @version 08.11.2018
 */ 
public class Lab05c
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      
      double accumulator;
      double number;
      boolean flag;
      String response;

      // program code
      System.out.println( "Start...");
      System.out.println( "Welcome to \"SimpleCalc\".");
      
      //setting variables to the appropriate value
      flag = true;
      accumulator = 0;
      
      do
      {
         //main interface
         System.out.println( "The accumulator result is [ " + accumulator + " ].");
         System.out.println( "Please type in what you want to do:");
         System.out.println( "+,-,*,/ value");
         System.out.println( "Clear");
         System.out.println( "Quit");
         response = scan.nextLine();
         
         //summation operator
         if ( response.charAt(0) == '+')
         {
            response = response.replace( "+", "");
            response = response.replace( " ", "");
            number = Double.parseDouble( response);
            accumulator = accumulator + number;
         }
         
         //subtraction operator
         else if ( response.charAt(0) == '-')
         {
            response = response.replace( "-", "");
            response = response.replace( " ", "");
            number = Double.parseDouble( response);
            accumulator = accumulator - number;
         }
         
         //multiplication operator
         else if ( response.charAt(0) == '*')
         {
            response = response.replace( "*", "");
            response = response.replace( " ", "");
            number = Double.parseDouble( response);
            accumulator = accumulator * number;
         }
         
         //division operator
         else if ( response.charAt(0) == '/')
         {
            response = response.replace( "/", "");
            response = response.replace( " ", "");
            number = Double.parseDouble( response);
            if ( number == 0)
            {
               System.out.println( "Cannot divide by 0!");
               flag = false;
            }
            else
            {
               accumulator = accumulator / number;
            }
         }
         
         //clear operator
         else if ( response.equalsIgnoreCase( "clear") || response.equalsIgnoreCase( "c"))
            accumulator = 0;
         
         //quit operator
         else if ( response.equalsIgnoreCase( "quit") || response.equalsIgnoreCase( "q"))
            flag = false;
         
         //invalid input message
         else
            System.out.println( "Invalid input!");
         
      }while ( flag);

      System.out.println( "End.");
   }

}