import java.util.Scanner;

/**
 * Prints a coordinate grid, multiplication table, cell number, and row number. 
 * @author Alp �neri
 * @version 08.11.2018
 */ 
public class Lab05b
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants
      
      final int MAX_NUMBER_PER_CELL = 10;

      // variables
      
      int row;
      int col;
      int row1;
      int col1;
      String xString;
      String yString;
      int xLength;
      int yLength;
      String xyString;
      int xyLength;
      String iString;
      int iLength;
      int x;
      int y;
      int i;

      // program code
      System.out.println( "Start...");
      
      //getting the row and column numbers
      System.out.print( "Please enter the number of rows.");
      row = scan.nextInt();
      System.out.print( "Please enter the number of columns.");
      col = scan.nextInt();

      //setting values appropriately
      row1 = row;
      col1 = col;
      
      //first task
      System.out.println( "First task");
      for ( x = 1; x <= row1; x++)
      {
         for ( y = 1; y <= col1; y++)
         {
            xString = Integer.toString( x);
            yString = Integer.toString( y);
            xLength = xString.length();
            yLength = yString.length();
               for ( i = 0; i + xLength + yLength + 1 < MAX_NUMBER_PER_CELL; i++)
                  System.out.print( " ");
            System.out.print( x + "," + y);
         }
      System.out.println();
      }
      
      System.out.println();
      
      //setting values appropriately
      row1 = row;
      col1 = col;
      
      //second task
      System.out.println( "Second task");
      for ( x = 1; x <= row1; x++)
      {
         for ( y = 1; y <= col1; y++)
         {
            xyString = Integer.toString( x * y);
            xyLength = xyString.length();
               for ( i = 0; i + xyLength < MAX_NUMBER_PER_CELL; i++)
                  System.out.print( " ");
            System.out.print( x * y);
         }
      System.out.println();
      }
      
      System.out.println();
      
      //setting values appropriately
      row1 = row;
      col1 = col;
      
      //third task
      System.out.println( "Third task");
      for ( i = 1; i <= row1 * col1; i++)
      {
         iString = Integer.toString( i - 1);
         iLength = iString.length();
         for ( x = 0; x + iLength < MAX_NUMBER_PER_CELL; x++)
            System.out.print( " ");
         System.out.print( i - 1);
         if ( i != 0 && i % col1 == 0)
            System.out.println();
      }
      
      System.out.println();
      
      //setting values appropriately
      row1 = row;
      col1 = col;
      
      //fourth task
      System.out.println( "Fourth task");
      for ( i = 1; i <= row1; i++)
      {
         iString = Integer.toString( i);
         iLength = iString.length();
         for ( x = 0; x + iLength < MAX_NUMBER_PER_CELL; x++)
            System.out.print( " ");
         System.out.print( i);
         for ( x = 1; x < col1; x++)
            System.out.print( "         -");
         System.out.println();
      }
      
      System.out.println( "End.");
   }

}