import java.util.Scanner;

/**
 * Prints rectangle with a hole in the middle. 
 * @author Alp �neri
 * @version 08.11.2018
 */ 
public class Lab05a
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      
      int width;
      int height;
      int thickness;
      int thickness1;
      int width1;
      int height1;
      int rowCheck;
      int columnCheck;
      boolean flag;
      String response;
      String ch;
      

      // program code
      System.out.println( "Start...");
      
      //setting flag to the appropriate value
      flag = true;
         
      do
      {
         //getting values from the user
         System.out.print( "Please enter the character you wish to form a rectangle of.");
         ch = scan.next();
         System.out.print( "Please enter the width of the rectangle you want to form.");
         width = scan.nextInt();
         System.out.print( "Please enter the height of the rectangle you want to form.");
         height = scan.nextInt();
         System.out.print( "Please enter the thickness of the rectangle you want to form.");
         thickness = scan.nextInt();
         
         //checking the values
         if ( width <= 0 || height <= 0 || thickness <= 0)
         {
            System.out.println( "All values entered must be positive!");
            flag = false;
         }
         else
         {
            
            //setting the values appropriately
            thickness1 = thickness;
            width1 = width;
            
            //printing the lines without the spaces
            while ( thickness1 > 0)
            {
               if ( width1 == 0)
               {
                  System.out.println();
                  thickness1 --;
                  width1 = width;
               }
               else
               {
                  for ( width1 = width; width1 > 0; width1--)
                  {
                     System.out.print( ch);
                  }
               }
            }
         
            //setting the values appropriately
            thickness1 = thickness;
            height1 = height;
            width1 = width;
            rowCheck = ( height1 - ( 2 * thickness));
            columnCheck = ( width1 - ( 2 * thickness));
            
            //printing the lines with spaces
            while ( rowCheck > 0)
            {
               thickness1 = thickness;
               
               //printing the characters
               while ( thickness1 > 0)
               {
                  System.out.print( ch);
                  thickness1 --;
               }
               
               columnCheck = ( width1 - ( 2 * thickness));
               
               //printing the spaces
               while ( columnCheck > 0)
               {
                  System.out.print( " ");
                  columnCheck --;
               }
            
               thickness1 = thickness;
               
               //printing the characters
               while (thickness1 > 0)
               {
                  System.out.print( ch);
                  thickness1 --;
               }
               System.out.println();
               rowCheck --;
            }
            
            //setting the values appropriately
            thickness1 = thickness;
            width1 = width;
            
            //printing the lines without spaces
            while ( thickness1 > 0)
            {
               if ( width1 == 0)
               {
                  System.out.println();
                  thickness1 --;
                  width1 = width;
               }
               else
               {
                  for ( width1 = width; width1 > 0; width1--)
                  {
                     System.out.print( ch);
                  }
               }
            }
            
         //checking if there is a hole
         columnCheck = ( width - ( 2 * thickness));
         rowCheck = ( height - ( 2 * thickness));
         if ( columnCheck <= 0 || rowCheck <= 0)
            System.out.println( "No hole in the rectangle!");
         
         //asking the user if they want another pattern
         System.out.print( "Another pattern?");
         response = scan.next();
         
         if ( !response.equalsIgnoreCase( "y"))
            flag = false;
         }
         
      } while ( flag);
      
      System.out.println( "Goodbye.");
      System.out.println( "End.");
   }

}
