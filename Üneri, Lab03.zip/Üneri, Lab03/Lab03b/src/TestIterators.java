import java.util.Iterator;
import iterator.*;

/**
 * Tests the IntBagIterator class. 
 * @author Alp �neri
 * @version 10.3.19
 */ 
public class TestIterators
{
   public static void main( String[] args)
   {
      IntIterator i;
      Iterator<Integer> j;
      IntBag bag;

      bag = new IntBag();
      i = new IntBagIterator( bag);
      
      bag.add(17);
      bag.add(43);
      bag.add(34);
      for ( int k = 0; k < 2; k++)
      {
         bag.add(k);
      }
      
      while ( i.hasNext() ) 
      {
         System.out.println( i.nextInt() );
         
         //j = new IntBagIterator( bag);
          j = bag.iterator();
         
         while ( j.hasNext() )
         {
            System.out.println( "--" + j.next() );
         }
      }
   }
}