package iterator;
import java.util.Iterator;

/**
 * @author Alp �neri
 * @version __date__
 */
public interface IntIterator extends Iterator
{  
   // methods
   public abstract int nextInt();
}