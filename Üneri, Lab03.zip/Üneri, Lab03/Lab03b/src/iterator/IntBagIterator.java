package iterator;
import java.util.Iterator;

/**
 * Extends the Iterator class to iterate through an IntBag object.
 * @author Alp �neri
 * @version 10.3.19
 */ 
public class IntBagIterator implements IntIterator//, Iterator<Integer>
{
   // properties
   IntBag aBag;
   int index;

   // constructors
   
   /**
    * Creates an IntBagIterator object of the bag.
    * @param bag The IntBag object to be iterated.
    */ 
   public IntBagIterator( IntBag bag)
   {
      aBag = bag;
      index = 0;
   }
   
   // methods
   
   /**
    * Returns the next Integer object within the IntBag.
    * @return The next Integer object within the IntBag.
    */ 
   public Integer next()
   {
      Integer i = new Integer( aBag.get(index));
      index++;
      return i;
   }
   
   /**
    * Returns the next int within the IntBag.
    * @return The next int within the IntBag.
    */ 
   public int nextInt()
   {
      int i = (int) aBag.get(index);
      index++;
      return i;
   }
   
   /**
    * Returns true if the IntBag has another object to be iterated, false if not.
    * @return True if the IntBag has another object to be iterated, false if not.
    */ 
   public boolean hasNext()
   {
      return index < aBag.getValid();
   }
}