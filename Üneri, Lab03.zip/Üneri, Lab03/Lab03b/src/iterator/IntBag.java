package iterator;
import java.util.Iterator;

/**
 * A class that allows a variable sized collection of integer values to be stored.
 * @author Alp �neri
 * @version 10.3.19
 */
public class IntBag 
{
   // properties
   private int[] bag;
   private int valid;

   // constructors  
   
   /**
    * Creates an empty collection of size 100.
    */
   public IntBag()
   {
      bag = new int[100];
      valid = 0;
   }
   
   /**
    * Creates an empty collection of size given.
    * @param size The size of the empty collection to be created.
    */ 
   public IntBag( int size)
   {
      if ( size > 0)
         bag = new int[size];
      
      valid = 0;
   }
   
   // methods
   
   /**
    * Adds the given integer to the end of the collection.
    * @param i The integer to be added to the end of the collection.
    * @return True if value is added, false if not.
    */ 
   public boolean add( int i)
   {
      if ( valid < bag.length)
      {
         bag[valid] = i;
         valid++;
         
         return true;
      }
      
      return false;
   }
   
   /**
    * Adds the given integer to the given index and makes room by shifting the
    * ones after the index specified by one.
    * @param i The integer to be added to the index specified.
    * @param index The index the integer specified is to be added.
    * @return True if value is added, false if not.
    */ 
   public boolean add( int i, int index)
   {
      if ( index <= bag.length - 1)
      {
         int[] bagCopy = bag.clone();
         
         for ( int j = index; j < bag.length - 1; j++)
            bag[j + 1] = bagCopy[j];
         
         bag[index] = i;

         if ( valid < bag.length)
            valid++;
         
         return true;
      }
      
      return false;
   }
   
   /**
    * Removes the integer at the specified index by moving all the integers
    * past the specified index by one.
    * @param index The index of the integer to be removed.
    */ 
   public void remove( int index)
   {
      int[] bagCopy = bag.clone();
      
      for ( int i = index + 1; i < bag.length; i++)
         bag[i - 1] = bagCopy[i];
      
      valid--;
   }
   
   /**
    * Checks whether the specified integer is in the collection.
    * @param i The integer to be found in the collection.
    */ 
   public boolean contains( int i)
   {
      for ( int j = 0; j < valid; j++)
         if ( bag[j] == i)
            return true;
      return false;
   }
   
   /**
    * Returns a string representation of the collection.
    * @return A string representation of the collection.
    */ 
   public String toString()
   {
      if ( valid > 0)
      {
         String s = "[ ";
         
         for ( int i = 0; i < valid - 1; i++)
            s = s + bag[i] + ", ";
         
         s = s + bag[valid - 1] + " ]";
         
         return s;
      }
      
      return "[ ]";
   }
   
   /**
    * Returns the integer at the specified index value.
    * @param index The index value for the integer to be returned.
    * @return The integer value at the specified index.
    */
   public int get( int index)
   {
      return bag[index];
   }
   /**
    * Returns the size of the collection.
    * @return The size of the collection.
    */ 
   public int size()
   {
      return bag.length;
   }
   
   /**
    * Returns the valid value.
    * @return The valid value.
    */ 
   public int getValid()
   {
      return valid;
   }
   
   /**
    * Returns the indexes of the value entered if value is in collection.
    * @param test The value to be searched.
    * @return The indexes of the value being searched for.
    */
   public IntBag findAll( int test)
   {
      IntBag indexes = new IntBag();
      
      for ( int i = 0; i < valid; i++)
      {
         if ( bag[i] == test)
            indexes.add( i);
      }
      
      return indexes;
   }
   
   /**
    * Creates an Iterator of Integer types for the IntBag object.
    * @return An Iterator of Integer types for the IntBag object.
    */ 
   public Iterator<Integer> iterator()
   {
      Iterator<Integer> i;
      
      i = new IntBagIterator( this);
      
      return i;
   }
}