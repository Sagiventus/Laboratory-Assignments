import java.util.Scanner;
import shapes.*;

/**
 * Tests the Shape and ShapeContainer classes. 
 * @author Alp �neri
 * @version 10.3.19
 */ 
public class ShapeTester
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);
      
      // variables
      ShapeContainer shapes;
      int response;
      int response1;
      int response2;
      boolean quit;

      // program code      
      quit = false;
      shapes = new ShapeContainer();

      System.out.println( "Welcome to ShapeTester. \n");
      
      do
      {
         //main interface
         System.out.println( "Please select a task to perform: ");
         System.out.println( "1: Create an empty collection of shapes.");
         System.out.println( "2: Add a rectangle with its lower left corner at (0,0) to the collection.");
         System.out.println( "3: Add a circle centered on (0,0) to the collection.");
         System.out.println( "4: View the total area of the shapes within the collection.");
         System.out.println( "5: View information regarding the shapes within the collection.");
         System.out.println( "6: Find the first shape that contains a point.");
         System.out.println( "7: Remove all selected shapes from the collection.");
         System.out.println( "8: Quit.");
         System.out.print( "Awaiting input: ");
         
         response = scan.nextInt();
         
         //create empty collection operator
         if ( response == 1)
         {
            shapes = new ShapeContainer();
            System.out.println( "Collection successfully created. \n");
         }
         
         //add rectangle operator
         else if ( response == 2)
         {
            System.out.print( "Please enter the width of the rectangle you'd like to add to the collection: ");
            response1 = scan.nextInt();
            System.out.print( "Please enter the height of the rectangle you'd like to add to the collection: ");
            response2 = scan.nextInt();
            
            if ( response1 == response2)
            {
               shapes.add( new Square( response1));
               System.out.println( "Square successfully added to the collection. \n");
            }
            else
            {
            shapes.add( new Rectangle( response1, response2));
            System.out.println( "Rectangle successfully added to the collection. \n");
            }
         }
         
         //add circle operator
         else if ( response == 3)
         {
            System.out.print( "Please enter the radius of the circle you'd like to add to the collection: ");
            response1 = scan.nextInt();
            
            shapes.add( new Circle( response1));
            System.out.println( "Circle successfully added to the collection. \n");
         }
         
         //view total area operator
         else if ( response == 4)
         {
            System.out.println( "The total area of the shapes within the collection is: " + shapes.getArea() + "\n");
         }
         
         //view shapes operator
         else if ( response == 5)
         {
            System.out.println( shapes + "\n");
         }
         
         //locate operator
         else if ( response == 6)
         {
            System.out.print( "Please enter the x-coordinate of the point: ");
            response1 = scan.nextInt();
            System.out.print( "Please enter the y-coordinate of the point: ");
            response2 = scan.nextInt();
            
            System.out.println( "The first shape containing the point is: " + shapes.locate( response1, response2));
            
            if ( shapes.locate( response1, response2) == null)
            {
               System.out.println();
            }
            
            if ( shapes.locate( response1, response2) != null)
            {
               System.out.println( "Select shape?");
               System.out.println( "1: Yes.");
               System.out.println( "2: No.");
               System.out.print( "Awaiting input: ");
               response1 = scan.nextInt();
               
               if ( response1 == 1 && shapes.locate( response1, response2).isRectangle())
               {
                  ( (Rectangle) shapes.locate( response1, response2)).setSelected( true);
                  System.out.println( "Shape successfully selected. \n");
               }
               else if ( response1 == 1 && !shapes.locate( response1, response2).isRectangle())
               {
                  ( (Circle) shapes.locate( response1, response2)).setSelected( true);
                  System.out.println( "Shape successfully selected. \n");
               }
               else if ( response1 == 2 && shapes.locate( response1, response2).isRectangle())
               {
                  ( (Rectangle) shapes.locate( response1, response2)).setSelected( false);
                  System.out.println( "Shape not selected. \n");
               }
               else if ( response1 == 2 && !shapes.locate( response1, response2).isRectangle())
               {
                  ( (Circle) shapes.locate( response1, response2)).setSelected( false);
                  System.out.println( "Shape not selected. \n");
               }
            }
         }
         
         //remove selected shapes operator
         else if ( response == 7)
         {
            shapes.removeSelectedShapes();
            System.out.println( "All selected shapes successfully removed. \n");
         }
         
         //quit operator
         else if ( response == 8)
         {
            quit = true;
         }
         
         //invalid input operator
         else
         {
            System.out.println( "Invalid input!" + "\n");
         }
         
      } while ( !quit);

      System.out.println( "End.");
   }

}