package shapesinterface;

/**
 * Allows for an object to be locatable on a two-dimensional coordinate system. 
 * @author Alp �neri
 * @version 10.3.19
 */ 
public interface Locatable
{
   /**
    * Returns the x-coordinate of the shape.
    * @return The x-coordinate of the shape.
    */ 
   public abstract int getX();
   
   /**
    * Returns the y-coordinate of the shape.
    * @return The y-coordinate of the shape.
    */ 
   public abstract int getY();
   
   /**
    * Sets the location of the shape to the given point.
    * @param x The x-coordinate of the point.
    * @param y The y-coordinate of the point.
    */ 
   public abstract void setLocation( int x, int y);
}