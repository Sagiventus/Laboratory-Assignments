package shapesinterface;
import shapes.*;

/**
 * Allows for an object to be selectable. 
 * @author Alp �neri
 * @version 10.3.19
 */ 
public interface Selectable
{
   /**
    * Returns the selected value of the shape.
    * @return The selected value of the shape.
    */ 
   public abstract boolean getSelected();
   
   /**
    * Sets the selected value of the shape.
    * @param b The new selected value of the shape.
    */ 
   public abstract void setSelected( boolean b);
   
   /**
    * Returns the shape if it contains the given point, null if it does not.
    * @return The shape if it contains the given point, null if it does not.
    */ 
   public abstract Shape contains( int x, int y);
}