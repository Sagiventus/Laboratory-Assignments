package shapes;
import shapesinterface.Locatable;

/**
 * Abstract class to group shapes together with a mandatory getArea method. 
 * @author Alp �neri
 * @version 10.3.19
 */ 
public abstract class Shape implements Locatable
{
   // properties
   int xCoordinate;
   int yCoordinate;

   // constructors
   
   /**
    * Creates a new shape at the location (0,0).
    */ 
   public Shape()
   {
      xCoordinate = 0;
      yCoordinate = 0;
   }
   
   // methods
   
   /**
    * Returns the area of the shape.
    * @return The area of the shape.
    */ 
   public abstract double getArea();
   
   /**
    * Returns true if the shape is a rectangle, false if it is not.
    * @return True if the shape is a rectangle, false if it is not.
    */ 
   public abstract boolean isRectangle();
   
   /**
    * Returns the x-coordinate of the shape.
    * @return The x-coordinate of the shape.
    */ 
   public int getX()
   {
      return xCoordinate;
   }
   
   /**
    * Returns the y-coordinate of the shape.
    * @return The y-coordinate of the shape.
    */ 
   public int getY()
   {
      return yCoordinate;
   }
   
   /**
    * Sets the x-coordinate and y-coordinate of the shape.
    * @param x The  new x-coordinate of the shape.
    * @param y The  new y-coordinate of the shape.
    */ 
   public void setLocation( int x, int y)
   {
      xCoordinate = x;
      yCoordinate = y;
   }
}