package shapes;
import java.util.ArrayList;
import shapes.*;

/**
 * Class to contain an ArrayList of Shapes. 
 * @author Alp �neri
 * @version 10.3.19
 */ 
public class ShapeContainer
{
   // properties
   ArrayList<Shape> shapes;

   // constructors
   /**
    * Creates a new ShapeContainer object without any shapes in it.
    */ 
   public ShapeContainer()
   {
      shapes = new ArrayList<Shape>();
   }
   
   // methods
   
   /**
    * Adds the given shape to the collection.
    * @param s The shape to be added to the collection.
    */ 
   public void add( Shape s)
   {
      shapes.add( s);
   }
   
   /**
    * Returns a String representation of the collection.
    * @return A String representation of the collection.
    */ 
   public String toString()
   {
      String s = "";
      
      for ( int i = 0; i < shapes.size(); i++)
      {
         s = s + shapes.get(i).toString() + "\n";
      }
      
      if ( shapes.size() == 0)
      {
         return "The collection is empty!";
      }
      
      return s;
   }
   
   /**
    * Returns the total area of all the shapes within the collection.
    * @return The total area of all the shapes within the collection.
    */ 
   public double getArea()
   {
      double area;
      
      area = 0;
      
      for ( int i = 0; i < shapes.size(); i++)
      {
         area = area + shapes.get(i).getArea();
      }
      
      return area;
   }
   
   /**
    * Returns the first shape that contains the given point, null if no such shape exists.
    * @param x The x-coordinate of the point.
    * @param y The y-coordinate of the point.
    * @return The first shape that contains the given point, null if no such shape exists.
    */ 
   public Shape locate( int x, int y)
   {
      for ( int i = 0; i < shapes.size(); i++)
      {
         if ( shapes.get(i).isRectangle())
         {
            if ( ( (Rectangle) shapes.get(i)).contains( x, y) != null)
            {
               return shapes.get(i);
            }
         }
         else
         {
            if ( ( (Circle) shapes.get(i)).contains( x, y) != null)
            {
               return shapes.get(i);
            }
         }
      }
      return null;
   }
   
   /**
    * Removes the selected shapes.
    */ 
   public void removeSelectedShapes()
   {
      for ( int i = 0; i < shapes.size(); i++)
      {
         if ( shapes.get(i).isRectangle())
         {
            if ( ( (Rectangle) shapes.get(i)).getSelected())
            {
               shapes.remove(i);
            }
         }
         else
         {
            if ( ( (Circle) shapes.get(i)).getSelected())
            {
               shapes.remove(i);
            }
         }
      }
   }
}