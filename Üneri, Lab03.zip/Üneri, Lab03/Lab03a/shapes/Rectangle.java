package shapes;
import shapesinterface.Selectable;

/**
 * Rectangle class that extends the Shape class. 
 * @author Alp �neri
 * @version 10.3.19
 */ 
public class Rectangle extends Shape implements Selectable
{
   // properties
   int width;
   int height;
   boolean selected;

   // constructors
   
   /**
    * Creates a new Rectangle object with its lower left corner at (0,0) with the given width and height.
    * @param width The width of the rectangle to be created.
    * @param height The height of the rectangle to be created.
    */ 
   public Rectangle( int width, int height)
   {
      this.width = width;
      this.height = height;
   }
   
   // methods
   
   /**
    * Returns the area of the Rectangle object.
    * @return The area of the Rectangle object.
    */ 
   public double getArea()
   {
      return width * height;
   }
   
   /**
    * Returns a String representation of the Rectangle object.
    * @return A String representation of the rectangle.
    */ 
   public String toString()
   {
      return "Rectangle: Width: " + width + " Height: " + height 
         + " Area: " + this.getArea() + " Selected: " 
         + this.getSelected() + "\n";
   }
   
   /**
    * Returns the selected value of the Rectangle object.
    * @return The selected value of the rectangle.
    */ 
   public boolean getSelected()
   {
      return selected;
   }
   
   /**
    * Sets the selected value of the Rectangle object.
    * @param b The new selected value of the rectangle.
    */ 
   public void setSelected( boolean b)
   {
      selected = b;
   }
   
   /**
    * Returns the Rectangle if it contains the given point, null if it does not.
    * @return The Rectangle if it contains the given point, null if it does not.
    */ 
   public Shape contains( int x, int y)
   {
      if ( this.getX() + width >= x && this.getX() <= x)
      {
         if ( this.getY() + height >= y && this.getY() <= y)
         {
            return this;
         }
      }
      return null;
   }
   
   /**
    * Returns true if the shape is a rectangle, false if it is not.
    * @return True if the shape is a rectangle, false if it is not.
    */ 
   public boolean isRectangle()
   {
      return true;
   }
}