package shapes;
import shapesinterface.Selectable;

/**
 * Circle class that extends the Shape class. 
 * @author Alp �neri
 * @version 10.3.19
 */ 
public class Circle extends Shape implements Selectable
{
   // properties
   int radius;
   boolean selected;

   // constructors
   
   /**
    * Creates a new Circle object centered at (0,0) with the given radius.
    * @param radius The radius of the circle to be created.
    */ 
   public Circle( int radius)
   {
      this.radius = radius;
   }
   
   // methods
   
   /**
    * Returns the area of the Circle object.
    * @return The area of the Circle object.
    */ 
   public double getArea()
   {
      return Math.PI * radius * radius;
   }
   
   /**
    * Returns a String representation of the Circle object.
    * @return A String representation of the circle.
    */ 
   public String toString()
   {
      return "Circle: Radius: " + radius + " Area: " 
         + this.getArea() + " Selected: " + this.getSelected() + "\n";
   }
   
   /**
    * Returns the selected value of the Circle object.
    * @return The selected value of the circle.
    */ 
   public boolean getSelected()
   {
      return selected;
   }
   
   /**
    * Sets the selected value of the Circle object.
    * @param b The new selected value of the circle.
    */ 
   public void setSelected( boolean b)
   {
      selected = b;
   }
   
   /**
    * Returns the Circle if it contains the given point, null if it does not.
    * @return The Circle if it contains the given point, null if it does not.
    */ 
   public Shape contains( int x, int y)
   {
      if ( this.getX() - this.radius <= x && x <= this.getX() + this.radius)
      {
         if ( this.getY() - this.radius <= y && y <= this.getY() + this.radius)
         {
            return this;
         }
      }
      return null;
   }
   
   /**
    * Returns true if the shape is a rectangle, false if it is not.
    * @return True if the shape is a rectangle, false if it is not.
    */ 
   public boolean isRectangle()
   {
      return false;
   }
}