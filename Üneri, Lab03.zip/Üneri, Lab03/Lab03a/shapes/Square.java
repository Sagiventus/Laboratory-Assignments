package shapes;

/**
 * Square class that extends the Rectangle classi 
 * @author Alp �neri
 * @version 10.3.19
 */ 
public class Square extends Rectangle
{
   // properties
   int side;

   // constructors
   /**
    * Creates a new square Rectangle object with the given side.
    * @param side The side of the square to be created.
    */ 
   public Square( int side)
   {
      super( side, side);
   }
   
   // methods
   
   /**
    * Returns a String representation of the Rectangle object.
    * @return A String representation of the square.
    */ 
   public String toString()
   {
      return "Square: Side: " + super.width + " Area: " + this.getArea() + 
         " Selected: " + this.getSelected() + "\n";
   }
}