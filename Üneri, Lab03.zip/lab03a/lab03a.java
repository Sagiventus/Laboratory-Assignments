import java.util.Scanner;

/**
 * Prints integers from 0 to 50, displays some of their properties. 
 * @author Alp �neri
 * @version 25.10.18
 */ 
public class lab03a
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables

      int odd;
      int even;
      
      int n;
      int addition;
      int additionCheck;
      
      // program code
      
      System.out.println( "Start...");
      
      odd = 0;
      even = 0;
      addition = 0;
      additionCheck = 0;
      
      System.out.println( "Please enter an integer value between 1 and 50.");
      n = scan.nextInt();
      additionCheck = ((n*(n+1)) / 2 );
      
      //checking if the int value entered is below 50 or not
      if ( n > 50 || n < 0)
         System.out.println( "The integer value entered is not between 1 and 50.");
      else
      { 
         
         for ( int x = 0; x <= 50; x++ ) 
         {               
            System.out.println( x);
            
            if ( x < 12 || x > 25 )
               System.out.println( " out of range 12-25 " );
            
            if ( x % 2 == 0 )
            {   even = (even + 1);
               System.out.println( " Hi Two "); 
            }
            else
               odd = (odd + 1);
            
            if ( x % 5 == 0 )
               System.out.println( " Hi Five ");
            
            if ( x % 3 == 0 || x % 7 == 0)
               System.out.println ( " Hi ThreeOrSeven");
            
            if ( (x % 3 != 0) & (x % 5 != 0) & (x % 2 != 0) & (x % 7 != 0) )
               System.out.println ( " Hi Others!");
            
            if ( x <= n)
               addition = (addition + x);
         }
         
         //printing the properties
         System.out.println( "The sum of the integers starting from 1 and up to the integer entered is " + addition);
         System.out.println( "The additionCheck value is " + additionCheck);
         
         if (addition == additionCheck)
            System.out.println( "The sum is equal to the value of additionCheck, everything seems fine.");
         else
            System.out.println( "The sum is not equal to the value of additionCheck, something went wrong!");
         
         System.out.println( "The number of odd numbers are " + odd);
         System.out.println ( "The number of even numbers are " + even);
         System.out.println( "End.");
      }
   }
}