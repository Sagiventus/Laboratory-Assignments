import java.util.Scanner;
import java.nio.file.*;   
import java.io.*;

/**
 * Inputs name, age, salary, and comment, outputs website 
 * @author Alp �neri
 * @version 18.10.18
 */ 
public class lab03c
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants
      
      final String doctype = "<!DOCTYPE html>";
      final String html = "<html>";
      final String head = "<head>";
      final String title = "<title>";
      final String title1 = "</title>";
      final String body = "<body>";
      final String hr = "<hr>";
      final String hl = "<hl>";
      final String hl1 = "</hl>";
      final String p = "<p>";
      final String p1 = "</p>";
      final String body1 = "</body>";
      final String html1 = "</html>";
         
      // variables
      
      String name;
      int age;
      double salary;
      String comment;
      double netSalary;
      double taxRate;

      // program code
      
      name = scan.nextLine();
      age = scan.nextInt();
      salary = scan.nextDouble();
      scan.nextLine();
      comment = scan.nextLine();
      
      // checking if the age and salary is positive and whether the salary exceeds 10 000
      if (age < 0 || salary < 0 || salary > 10000)
         System.out.println( "Invalid input!");
      else
      {      
         taxRate = 0.85;
         
         //adjusting the tax rates appropriate to the salary
         if (salary <= 1000)
            taxRate = 0.95;
         
         if (salary >= 5000)
            taxRate = 0.75;
         
         netSalary = ( (salary - 100) * taxRate );
         
         System.out.println( doctype);
         System.out.println( html);
         System.out.println( head);
         System.out.println( title + name + "'s Home Page)" + title1);
         System.out.println( body);
         System.out.println( hr);
         
         if (Files.exists( Paths.get( name + ".jpg" ) ))
            System.out.println( "<img src=\"" + name + ".jpg\">");
         
         System.out.println( hl + name + hl1);
         System.out.println( p + "Age: " + age + p1);
         System.out.println( p + "Salary: " + netSalary + " (%" + (taxRate * 100) + ")" + p1);
         System.out.println( p + "Comments: " + comment + p1);
         System.out.println( hr);
         System.out.println( body1);
         System.out.println( html1);
      }                         
   }

}