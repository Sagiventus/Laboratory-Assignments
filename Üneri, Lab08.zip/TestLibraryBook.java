import java.util.Scanner;
import book.LibraryBook;

/**
 * Tests the LibraryBook class. 
 * @author Alp �neri
 * @version 10.12.18
 */ 
public class TestLibraryBook
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      LibraryBook book1;
      LibraryBook book2;
      LibraryBook book3;

      // program code
      System.out.println( "Start...");
      
      //creating two books
      book1 = new LibraryBook( "Lord of the Flies", "William Golding");
      book2 = new LibraryBook( "What I Talk About When I Talk About Running", "Haruki Murakami");
      book3 = book1;

      /*//printing the two objects
      System.out.println( book1.toString());
      System.out.println( book2.toString());
      
      //formatting
      System.out.println();
      System.out.println( "Loaning Lord of the Flies");
      
      //loaning the first book
      book1.loanBook( "01.11.19");
      System.out.println( book1.toString());
      System.out.println( "The book is on loan: " + book1.onLoan());
      
      //formatting
      System.out.println();
      System.out.println( "Returning Lord of the Flies");
      
      //returning the first book
      book1.returnBook();
      System.out.println( book1.toString());
      System.out.println( "The book is on loan: " + book1.onLoan());
      
      *///formatting
      System.out.println( "Comparing .equals with == (Two references to a single object)");
      
      //comparing default .equals with == (Two references to a single object)
      System.out.println( "book1 == book3: " + (book1 == book3));
      System.out.println( "book1.equals( book3): " + (book1.equals( book3)));
      
      //formatting
      System.out.println();
      System.out.println( "Comparing .equals with == (Two references to two individual objects with different properties)");
      
      //comparing default .equals with == (Two references to two individual objects with different properties)
      System.out.println( "book1 == book2: " + (book1 == book2));
      System.out.println( "book1.equals( book2): " + (book1.equals( book2)));
      
      //formatting
      System.out.println();
      System.out.println( "Comparing .equals with == (Two references to two individual objects with identical properties)");
      
      //comparing default .equals with == (Two references to two individual objects with identical properties)
      book3 = new LibraryBook( "Lord of the Flies", "William Golding");
      System.out.println( "book1 == book3: " + (book1 == book3));
      System.out.println( "book1.equals( book3): " + (book1.equals( book3)));
      
      //formatting
      System.out.println();
      System.out.println( "Testing hasSameTitle");
      
      //testing hasSameTitle
      book3 = new LibraryBook( book1);
      System.out.println( "book1 == book3: " + (book1 == book3));
      System.out.println( "book1.equals( book3): " + (book1.equals( book3)));
      System.out.println( "book1.hasSameTitle( book3): " + (book1.hasSameTitle( book3)));
      System.out.println( "book1.hasSameTitle( book2): " + (book1.hasSameTitle( book2)));
      
      //formatting
      System.out.println();
      System.out.println( "Testing hasSameAuthor");
      
      //testing hasSameAuthor
      System.out.println( "book1.hasSameAuthor( book3): " + (book1.hasSameAuthor( book3)));
      System.out.println( "book1.hasSameAuthor( book2): " + (book1.hasSameAuthor( book2)));
      
      System.out.println( "End.");
   }

}