package book;

/**
 * @author Alp �neri
 * @version 10.12.18
 */
public class Library 
{
   // properties
   private LibraryBook b1;
   private LibraryBook b2;
   private LibraryBook b3;
   private LibraryBook b4;

   // constructors
   public Library()
   {
      b1 = null;
      b2 = null;
      b3 = null;
      b4 = null;
   }
   
   // methods
   
   /**
   * Returns true if the library is empty and false if it is not.
   */
   public boolean isEmpty()
   {
      return ( b1 == null && b2 == null && b3 == null && b4 == null);
   }

   
   /**
   * Returns the library in string format.
   * @return The library in string format
   */
   public String toString()
   {
      return ("The library has books: \n " + b1 + " \n " + b2 + " \n " + b3 + " \n " + b4);
   }
   
   /**
   * Adds the book with the specified title and author to the first null book.
   * @param title The title of the book to be added
   * @param author The author of the book to be added
   * @return True if book can be added, false if not
   */
   public boolean add( String title, String author)
   {
      if ( b1 == null)
         b1 = new LibraryBook( title, author);
      else if ( b2 == null)
         b2 = new LibraryBook( title, author);
      else if ( b3 == null)
         b3 = new LibraryBook( title, author);
      else if ( b4 == null)
         b4 = new LibraryBook( title, author);
      else
         return false;
      
      return true;
   }
   
   /**
   * Removes the specified book.
   * @param title The book to be removed
   * @return True if book is removed, false if not
   */
   public boolean remove( LibraryBook test)
   {
      if ( b1.equals( test))
         b1 = null;
      else if ( b2.equals( test))
         b2 = null;
      else if ( b3.equals( test))
         b3 = null;
      else if ( b4.equals( test))
         b4 = null;
      else
         return false;
      
      return true;
   }
   
   /**
   * Gets the book with the specified title.
   * @param title The title of the book to be found
   * @return The book with the specified title, null if no such book exists
   */
   public LibraryBook findByTitle( String title)
   {
      if ( b1 != null && ( b1.getTitle()).equals( title))
         return b1;
      else if ( b2 != null && ( b2.getTitle()).equals( title))
         return b2;
      else if ( b3 != null && ( b3.getTitle()).equals( title))
         return b3;
      else if ( b4 != null && ( b4.getTitle()).equals( title))
         return b4;
      else
         return null;
   }
}