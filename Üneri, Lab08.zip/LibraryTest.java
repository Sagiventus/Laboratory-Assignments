import java.util.Scanner;
import book.Library;

/**
 * Tests the Library class
 * @author Alp �neri
 * @version 13.12.18
 */ 
public class LibraryTest
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      Library library;
      boolean flag;
      boolean flag1;
      int response;
      String response1;
      int response2;
      String response3;
      String response4;
      String response5;

      // program code
      System.out.println( "Start...");
      
      //creating the library object
      library = new Library();
      flag = true;
      flag1 = true;
      
      do
      {
         //main interface
         System.out.println( "------------------");
         System.out.println( "Please press 1 to view the library.");
         System.out.println( "Please press 2 to find a book by its title.");
         System.out.println( "Please press 3 to add a book to the library.");
         System.out.println( "Please press 4 to exit.");
         System.out.println( "------------------");
         System.out.println( "1:SHOW   2:FIND   3:ADD   4:EXIT");
         response = scan.nextInt();
         scan.nextLine();
         
         //view operator
         if ( response == 1)
            System.out.println( library);
         
         //find operator
         else if ( response == 2)
         {
            System.out.println( "Please enter the title of the book you wish to find.");
            response1 = scan.nextLine();
            do
            {
               if ( library.findByTitle( response1) == null)
               {
                  System.out.println( "The book cannot be found.");
                  flag1 = false;
               }
               else
               {
                  System.out.println( library.findByTitle( response1));
                  System.out.println( "The book has succesfully been found.");
                  System.out.println( "------------------");
                  System.out.println( "Please press 1 to loan, 2 to return, 3 to remove the book, or 4 to exit back to the main menu.");
                  System.out.println( "1:LOAN   2:RETURN   3:REMOVE   4:EXIT");
                  response2 = scan.nextInt();
                  scan.nextLine();
                  
                  //loan operator
                  if ( response2 == 1)
                  {
                     System.out.print( "Please enter the due date.");
                     response3 = scan.nextLine();
                     
                     ( library.findByTitle( response1)).loanBook( response3);
                     System.out.println( "The book has succesfully been loaned.");
                  }
                  
                  //return operator
                  else if ( response2 == 2)
                  {
                     ( library.findByTitle( response1)).returnBook();
                     System.out.println( "The book has succesfully been returned.");
                  }
                  
                  //remove operator
                  else if ( response2 == 3)
                  {
                     library.remove( ( library.findByTitle( response1)));
                     System.out.println( "The book has succesfully been removed.");
                  }
                  
                  //exit operator
                  else if ( response2 == 4)
                  {
                     flag1 = false;
                  }
                  
                  //invalid input
                  else
                     System.out.println( "Invalid input, please try again.");
               }
            } while ( flag1);
         }
         
         //add operator
         else if ( response == 3)
         {
            System.out.print( "Please enter the title of the book you wish to add.");
            response4 = scan.nextLine();
            System.out.print( "Please enter the author of the book you wish to add.");
            response5 = scan.nextLine();
            
            library.add( response4, response5);
            System.out.println( "The book has succesfully been added.");
         }
         
         //exit operator
         else if ( response == 4)
            flag = false;
         
         //invalid input
         else
            System.out.println( "Invalid input, please try again.");
         
      } while( flag);


      System.out.println( "End.");
   }

}