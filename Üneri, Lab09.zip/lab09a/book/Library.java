package book;
import java.util.ArrayList;

/**
 * @author Alp �neri
 * @version 20.12.18
 */
public class Library 
{
   // properties
   private ArrayList<LibraryBook> books;

   // constructors
   public Library()
   {
      books = new ArrayList<LibraryBook>();
   }
   
   // methods
   
   /**
   * Returns true if the library is empty and false if it is not.
   */
   public boolean isEmpty()
   {
      return books.size() == 0;
   }

   
   /**
   * Returns the library in string format.
   * @return The library in string format
   */
   public String toString()
   {
      return books.toString();
   }
   
   /**
   * Adds the book with the specified title and author to the library.
   * @param title The title of the book to be added
   * @param author The author of the book to be added
   */
   public void add( String title, String author)
   {
      LibraryBook book;
      book = new LibraryBook( title, author);
      books.add( book);
   }
   
   /**
   * Removes the specified book.
   * @param title The book to be removed
   * @return True if book is removed, false if not
   */
   public boolean remove( LibraryBook test)
   {
      for ( int i = 0; i < books.size(); i++)
      {
         if ( books.get( i).equals( test))
         {
            books.remove( i);
            return true;
         }
      }
      return false;
   }
   
   /**
   * Gets the book with the specified title.
   * @param title The title of the book to be found
   * @return The book with the specified title, null if no such book exists
   */
   public LibraryBook findByTitle( String title)
   {
      for ( LibraryBook book : books)
      {
         if ( book.getTitle().equals( title))
            return book;
      }
      return null;
   }
}