package book;

/**
 * @author Alp �neri
 * @version 20.12.18
 */
public class LibraryBook 
{
   // properties
   private String title;
   private String author;
   private String dueDate;
   private int timesLoaned;
   private boolean onLoan;

   // constructors
   public LibraryBook( String theTitle, String theAuthor)
   {
      title = theTitle;
      author = theAuthor;
      dueDate = "";
      timesLoaned = 0;
      onLoan = false;
   }
   
   public LibraryBook( LibraryBook test)
   {
      this.title = test.title;
      this.author = test.author;
      this.dueDate = test.dueDate;
      this.timesLoaned = test.timesLoaned;
      this.onLoan = test.onLoan;
   }
   
   // methods
   
   /**
   * Returns the object in string format. 
   * @return The object in string format
   */
   public String toString()
   {
      return "Title: " + title + " Author: " + author + " Due Date: " + dueDate + 
         " Times Loaned: " + timesLoaned + "\n";
   }
   
   /**
   * Loans the book: changes the due date, sets onLoan to true, and increments times loaned.
   * @param newDueDate The new due date
   */
   public void loanBook( String newDueDate)
   {
      dueDate = newDueDate;
      timesLoaned++;
      onLoan = true;
   }
   
   /**
   * Returns the book: resets due date and sets onLoan to false.
   */
   public void returnBook()
   {
      dueDate = "";
      onLoan = false;
   }
   
   /**
   * Returns how many times the book has been loaned.
   * @return How many times the book has been loaned
   */
   public int getTimesLoaned()
   {
      return timesLoaned;
   }
   
   /**
   * Returns true if book is on loan and false if it is not.
   */
   public boolean onLoan()
   {
      return onLoan;
   }

   /**
   * Returns true if the two books are the same.
   * @param test The book to be compared to the other book
   * @return Whether the two books are the same
   */
   public boolean equals( LibraryBook test)
   {
      return (this.title == test.title && this.author == test.author);
   }
   
   /**
   * Returns true if the two books have the same title.
   * @param test The book to be compared to the other book
   * @return Whether the two books have the same title
   */
   public boolean hasSameTitle( LibraryBook test)
   {
      return this.title == test.title;
   }
   
   /**
   * Returns true if the two books have the same author.
   * @param test The book to be compared to the other book
   * @return Whether the two books have the same author
   */
   public boolean hasSameAuthor( LibraryBook test)
   {
      return this.author == test.author;
   }
   
   /**
   * Returns the title of the book specified.
   * @return The title of the book
   */
   public String getTitle()
   {
      return title;
   }
   
   /**
   * Returns the author of the book specified.
   * @return The author of the book
   */
   public String getAuthor()
   {
      return author;
   }
}