import java.util.Scanner;
import java.util.ArrayList;
import gambling.*;

/**
 * Prints histogram from dice rolls 
 * @author Alp �neri
 * @version 20.12.18
 */ 
public class Lab09b
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants
      final int NUMBER_OF_ROLLS = 1000;

      // variables
      Dice dice;
      ArrayList<Integer> list;
      int set1;
      int set2;

      // program code
      System.out.println( "Start...");
      
      //creating the objects
      dice = new Dice();
      list = new ArrayList<Integer>();
      
      //initializing the arraylist
      for ( int i = 0; i < 11; i++)
         list.add( 0);
      
      //counting the results from the rolls
      for ( int i = 0; i < NUMBER_OF_ROLLS; i++)
      {
         set1 = dice.rollTogether() - 2;
         set2 = list.get( set1) + 1;
         list.set( set1, set2);
      }
      
      //printing the data
      System.out.println( list);
      System.out.println( getFreqData( list));
      printHistogram( list);
   }
   
   /**
   * Gets the frequency data from list of dice roll results
   * @author Alp �neri
   * @version 20.12.18
   * @param list The list of dice roll results
   * @return The maximum frequency
   */ 
   public static int getFreqData( ArrayList<Integer> list)
   {
      int maxFreq = 0;
      
      for ( int i = 0; i < list.size(); i++)
         maxFreq = Math.max( maxFreq, list.get( i));
      
      if ( maxFreq % 10 == 0)
         return maxFreq / 10;
      
      if ( maxFreq < 10)
         maxFreq = 0;
      else if ( maxFreq > 10 && maxFreq < 10000)
         maxFreq = maxFreq / 10;
      else if ( maxFreq > 10000)
         maxFreq = maxFreq / 100;
      
      return maxFreq + 1;
   }
   
   /**
   * Prints histogram from dice rolls 
   * @author Alp �neri
   * @version 20.12.18
   * @param list The list of dice roll results
   */ 
   public static void printHistogram( ArrayList<Integer> list)
   {
      ArrayList<Integer> listForHistogram = new ArrayList<Integer>();
      
      for ( int i = 0; i < list.size(); i++)
         listForHistogram.add( list.get( i) / getFreqData( list));
      
      for ( int i = 0; i < 10; i++)
      {
         for ( int j = 0; j < listForHistogram.size(); j++)
         {
            if ( listForHistogram.get( j) + i >= 10)
               System.out.print( " * ");
            else 
               System.out.print( "   ");
         }
         System.out.println();
         
      }
      System.out.println( listForHistogram);
      
   }

}