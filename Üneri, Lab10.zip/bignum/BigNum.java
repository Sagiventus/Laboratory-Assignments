package bignum;

/**
 * @author Alp �neri
 * @version 25.12.18
 */
public class BigNum 
{
   // properties
   public static final int BASE = 10;
   public static final int SIZE = 4;
   public int[] number;

   // constructors
   public BigNum()
   {
      number = new int[SIZE];
   }
   
   public BigNum( String s)
   {
      number = new int[SIZE];
      for ( int i = 1; i <= s.length(); i++)
         number[i - 1] = Character.getNumericValue( s.charAt( s.length() - i));
   }
   
   public BigNum( BigNum b)
   {
      this.number = b.number.clone();
   }
   
   // methods
   
   /**
   * Returns the object in string format 
   * @author Alp �neri
   * @version 25.12.18
   * @return The object in string format
   */
   public String toString()
   {
      String s = "";
      for ( int i = 1; i <= number.length; i++)
         s = number[i - 1] + s;
      return s;
   }
   
   /**
   * Returns true if the numbers are equal, false if not 
   * @author Alp �neri
   * @version 25.12.18
   * @param other The second number
   * @return True if the numbers are equal, false if not
   */
   public boolean equals( BigNum other)
   {
      boolean b = true;
      for ( int i = 0; i < BigNum.SIZE; i++)
      {
         b = b && ( this.number[i] == other.number[i]);
      }
      return b;
   }
   
   /**
   * Returns true if the numbers is zero, false if not 
   * @author Alp �neri
   * @version 25.12.18
   * @return True if the numbers is zero, false if not
   */
   public boolean isZero()
   {
      boolean b = true;
      for ( int i : number)
         b = b && ( i == 0);
      return b;
   }
   
   /**
   * Multiplies the number by base if left is true, divides the number by base if left is false 
   * @author Alp �neri
   * @version 25.12.18
   * @param left Multiplies the number by base if true, divides the number by base if false
   */
   public void shift( boolean left)
   {
      int[] x = number.clone();
      if ( left)
      {
         for ( int i = 0; i < (x.length - 1); i++)
         {
            number[i + 1] = x[i];
         }
         number[0] = 0;
      }
      else
      {
         for ( int i = 1; i < x.length; i++)
            number[i - 1] = x[i];
         number[number.length - 1] = 0;
      }
      
   }
   
   /**
   * Returns true if first number is strictly less than the second 
   * @author Alp �neri
   * @version 25.12.18
   * @param other The second number
   * @return True if first number is strictly less than the second
   */
   public boolean isLessThan( BigNum other)
   {
      for ( int i = BigNum.SIZE - 1; i >= 0; i--)
      {
         if ( this.number[i] < other.number[i])
            return true;
         else if ( this.number[i] > other.number[i])
            return false;
      }
      return false;
   }
   
   /**
   * Adds the second number to the first number, returns any overflow 
   * @author Alp �neri
   * @version 25.12.18
   * @param other The second number
   * @return The overflow
   */
   public int add( BigNum other)
   {
      int overflow = 0;
      
      for ( int i = 0; i < BigNum.SIZE; i++)
      {
         int j = this.number[i] + other.number[i] + overflow;
         if ( j > BigNum.BASE - 1)
         {
            overflow = 1;
            j = j - BASE;
            this.number[i] = j;
         }
         else
         {
            overflow = 0;
            this.number[i] = j;
         }
         
      }
      return overflow;
      
   }

}