import bignum.BigNum;
import java.util.Scanner;

/**
 * Tests BigNum class 
 * @author Alp �neri
 * @version 25.12.18
 */ 
public class Lab10b
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);
      
      //constants
      final int BIGNUM_NO = 10;

      // variables
      BigNum[] numbers;
      BigNum[] numbersTemp;
      String s;
      boolean flag;
      int n;
      int index;
      BigNum max;

      // program code
      System.out.println( "Start...");
      
      //creating the BigNum arrays
      numbers = new BigNum[BIGNUM_NO];
      numbersTemp = new BigNum[BIGNUM_NO];
      index = 0;
      
      //adding random BigNums into the array
      for ( int i = 0; i < numbers.length; i++)
      {
         s = "";
         for ( int j = 0; j < BigNum.SIZE; j++)
         {
            s = s + (int) ( Math.random() * BigNum.BASE);
         }
         numbers[i] = new BigNum( s);
      }
      
      //printing the contents of the array
      for ( int i = 0; i < numbers.length; i++)
         System.out.println( numbers[i]);
      
      //formatting
      System.out.println();
      System.out.println( "Testing .isLessThan()");
      
      //testing .isLessThan
      System.out.println( "First.isLessThan( Second)): " + numbers[0].isLessThan( numbers[1]));
      
      //formatting
      System.out.println();
      System.out.println( "Main Task");
      
      //main task
      
      //setting the values appropriately
      flag = true;
      max = new BigNum();
      
      //sentinel value input
      System.out.print( "Please enter how many elements of the array you would like to check.");
      n = scan.nextInt();
      if ( n < 0)
         flag = false;
      
      //sentinel value input
      while ( flag)
      {  
         //finding the max value
         for ( int i = 0; i < n; i++)
            if ( max.isLessThan( numbers[i]))
            {  
            max = numbers[i];
            index = i;
            }
         
         //replacing the nth value with the max
         numbersTemp = numbers.clone();
         numbers[index] = numbersTemp[n - 1];
         numbers[n - 1] = max;
         
         //printing the contents of the array
         for ( int i = 0; i < numbers.length; i++)
            System.out.println( numbers[i]);
         
         //printing the max value
         System.out.println( "The maximum BigNum in the given number of elements is " + max + ".");
         
         //resetting the max value
         max = new BigNum();
         
         //sentinel value input
         System.out.print( "Please enter how many elements of the array you would like to check.");
         n = scan.nextInt();
         if ( n < 0)
            flag = false;
      }
      
      System.out.println( "End.");
   }

}