import bignum.BigNum;

/**
 * Tests BigNum class 
 * @author Alp �neri
 * @version 25.12.18
 */ 
public class Lab10a
{
   public static void main( String[] args)
   {
      // variables
      BigNum b1;
      BigNum b2;
      BigNum b3;

      // program code
      System.out.println( "Start...");
      
      //creating the BigNum objects
      b1 = new BigNum();
      b2 = new BigNum( "4567");
      b3 = new BigNum( b2);
      
      System.out.print( "b1: [");
      for ( int i = 0; i < b1.number.length - 1; i++)
      {
         System.out.print( b1.number[i] + ",");
      }
      System.out.println( b1.number[b1.number.length - 1] + "]");
      
      System.out.print( "b2: [");
      for ( int i = 0; i < b2.number.length - 1; i++)
      {
         System.out.print( b2.number[i] + ",");
      }
      System.out.println( b2.number[b2.number.length - 1] + "]");
      
      System.out.print( "b3: [");
      for ( int i = 0; i < b2.number.length - 1; i++)
      {
         System.out.print( b2.number[i] + ",");
      }
      System.out.println(b3.number[b3.number.length - 1] + "]");
      
      //formatting
      System.out.println();
      System.out.println( "Testing .toString()");
      
      System.out.println( "b1: " + b1);
      System.out.println( "b2: " + b2);
      System.out.println( "b3: " + b3);
      
      //formatting
      System.out.println();
      System.out.println( "Testing .equals()");
      
      System.out.println( "Clone.equals(): " + b2.equals( b3));
      System.out.println( "Different.equals(): " + b2.equals( b1));
      
      //formatting
      System.out.println();
      System.out.println( "Testing .isZero()");
      
      System.out.println( "Zero.isZero(): " + b1.isZero());
      System.out.println( "Non-zero.isZero(): " + b2.isZero());
      
      //formatting
      System.out.println();
      System.out.println( "Testing .shift( true)");
      
      //shifting to the right
      b1.shift( true);
      b2.shift( true);
      
      System.out.println( "b1.shift( true): " + b1);
      System.out.println( "b2.shift( true): " + b2);
      
      //formatting
      System.out.println();
      System.out.println( "Testing .shift( false)");
      
      //shifting to the left
      b1.shift( false);
      b3.shift( false);
      
      System.out.println( "b1.shift( false): " + b1);
      System.out.println( "b3.shift( false): " + b3);
      
      
      //formatting
      System.out.println();
      System.out.println( "Testing .add() w/ overflow");
      
      b2 = new BigNum( "7100");
      b3 = new BigNum( "5800");
      System.out.println( "The first number: " + b2);
      System.out.println( "The second number: " + b3);
      System.out.println( "Overflow: " + b2.add( b3)); 
      System.out.println( "Result: " + b2);
      
      //formatting
      System.out.println();
      System.out.println( "Testing .add() w/o overflow");
      
      b2 = new BigNum( "1101");
      b3 = new BigNum( "10");
      System.out.println( "The first number: " + b2);
      System.out.println( "The second number: " + b3);
      System.out.println( "Overflow: " + b2.add( b3)); 
      System.out.println( "Result: " + b2);
      
      System.out.println( "End.");
   }

}