package cs102;
import cs102.ds.List;

/**
 * Tests the List class. 
 * @author Alp �neri
 * @version 6.5.19
 */ 
public class TestList
{
   public static void main( String[] args)
   {
      // constants
      final String[] strings = { "delta", "echo", "foxtrot"};
      final String string = "Elementary";

      // variables
      List list;
      List a;
      List b;
      List merged;
      List containsTest;

      // program code
      list = new List();
      
      list.print();
      System.out.println( "Is Empty? " + list.isEmpty() + "\n");
      
      list.addToTail( "alp");
      list.addToHead( "mert");
      list.addToHead( "ege");
      list.addToTail( "z�beyir");
      System.out.print( "List: ");
      list.print();
      
      list.removeFromHead();
      System.out.print( "\nHead removed list: ");
      list.print();
      
      System.out.print( "\nReverse: ");
      list.printReverse();
      
      System.out.println( "\n\ngetData(0) " + list.getData(0));
      System.out.println( "\nIs Empty? " + list.isEmpty());
      
      System.out.println( "\nContains Alp? " + list.contains( "alp"));
      System.out.println( "Contains Baykam? " + list.contains( "baykam"));
      
      System.out.print( "\nList: ");
      list.print();
      System.out.println( "Is Ordered? " + list.isOrdered());
      
      list.removeFromHead();
      list.removeFromHead();
      list.removeFromHead();
      list.addToHead( "alpha");
      list.addToTail( "bravo");
      list.addToTail( "charlie");
      
      System.out.print( "\nList: ");
      list.print();
      System.out.println( "Is Ordered? " + list.isOrdered());
      
      System.out.println( "\nArray List: ");
      createFrom( strings).print();
      
      System.out.println( "\nString List: ");
      createFrom( string).print();
      
      a = new List();
      b = new List();
      
      a.addToTail( "alpha");
      a.addToTail( "bravo");
      a.addToTail( "charlie");
      
      b.addToTail( "alpha");
      b.addToTail( "delta");
      b.addToTail( "echo");
      
      System.out.print( "\nList A: ");
      a.print();
      
      System.out.print( "List B: ");
      b.print();
      
      System.out.print( "Merged List: ");
      merged = new List();
      merged = merged.merger( a, b);
      merged.print();
      
      containsTest = new List();
      containsTest.addToTail( "alpha");
      System.out.println( "\n" + containsTest.toString() + "\nContains Alpha? " + containsTest.contains( "alpha"));
   }
   
   public static List createFrom( String[] strings)
   {
      List list = new List();
      
      for ( int i = 0; i < strings.length; i++)
      {
         list.addToTail( strings[i]);
      }
      return list;
   }
   
   public static List createFrom( String string)
   {
      List list = new List();
      
      for ( int i = 0; i < string.length(); i++)
      {
         list.addToTail( string.charAt(i) + "");
      }
      return list;
   }
}