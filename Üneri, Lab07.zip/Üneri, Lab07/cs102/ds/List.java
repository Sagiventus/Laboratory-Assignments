package cs102.ds;

/**
 * List data structure to hold a collection of Strings. 
 * @author Alp �neri
 * @version 6.5.19
 */ 
public class List
{
   // properties
   Node head;
   
   // constructors
   public List()
   {
      head = null;
   }
   
   // methods
   
   /**
    * Adds a node containing the item to the head of the list.
    * @param item The String the node that will be added to the head of the list will contain.
    */ 
   public void addToHead( String item)
   {
      if ( head != null)
      {
         head = new Node( item, head);
      }
      else
      {
         head = new Node( item, null);
      }
   }
   
   /**
    * Adds a node containing the item to the tail of the list.
    * @param item The String the node that will be added to the tail of the list will contain.
    */ 
   public void addToTail( String item)
   {
      if ( tail() != null)
      {
         tail().next = new Node( item, null);
      }
      else
      {
         addToHead( item);
      }
   }
   
   /**
    * Removes the first node of the list.
    */ 
   public void removeFromHead()
   {
      if ( head != null)
      {
         head = head.next;
      }
   }
   
   /**
    * Returns true if the list is empty, false otherwise.
    * @return True if the list is empty, false otherwise.
    */ 
   public boolean isEmpty()
   {
      return head == null;
   }
   
   /**
    * Returns the data of the node at the specified index, null if the index is invalid.
    * @param index The index of the node whose data will be returned.
    * @return The data of the node at the specified index, null if the index is invalid.
    */ 
   public String getData( int index)  
   {
      Node tmp = head;
      int iter = 0;
      
      while ( iter < index)
      {
         if ( tmp != null)
         {
            tmp = tmp.next;
         }
         iter++;
      }
      
      if ( tmp != null)
      {
         return tmp.data;
      }
      return null;
   }
   
   /**
    * Prints the contents of the list to the console.
    */ 
   public void print()
   {
      if ( isEmpty())
      {
         System.out.println( "The list is empty.");
      }
      else
      {
         System.out.println( toString());
      }
   }
   
   /**
    * Recursively prints the contents of the list starting from the specified node in reverse order.
    * @param n A reference to the current node for recursive purposes.
    */ 
   public void printReverse( Node n)
   {
      if ( n != null)
      {
         if ( n != head)
         {
            System.out.print( n.data + ", ");
         }
         else
         {
            System.out.print( n.data);
         }
      }
      
      if ( n != head)
      {
         printReverse( previous( n));
      }
   }
   
   /**
    * Recursively prints the entire contents of the list in reverse order.
    */ 
   public void printReverse()
   {
      printReverse( tail());
   }
   
   /**
    * Returns true if the list contains the given target, false if otherwise.
    * @param target The target String to be searched within the list.
    * @return True if the list contains the given target, false if otherwise.
    */ 
   public boolean contains( String target)
   {
      Node tmp = head;
      
      while ( tmp != null)
      {
         if ( tmp.data.equals( target))
         {
            return true;
         }
         tmp = tmp.next;
      }
      return false;
   }
   
   /**
    * Returns true if the list is in lexicographic order, false if otherwise.
    * @return True if the list is in lexicographic order, false if otherwise.
    */ 
   public boolean isOrdered()    
   {
      Node tmp = head;
      boolean result = true;
      int i = 0;
      
      while ( tmp.next != null)
      {
         if ( getData(i).compareTo( getData(i + 1)) > 0)
         {
            result = false;
         }
         tmp = tmp.next;
      }
      return result;
   }
   
   /**
    * Returns a String representation for the list.
    * @return A String representation for the list.
    */ 
   public String toString()
   {
      String s = "";
      Node tmp = head;
      
      while ( tmp != null)
      {
         if ( tmp != tail())
         {
            s = s + tmp.data + ", ";
         }
         else
         {
            s = s + tmp.data;
         }
         tmp = tmp.next;
      }
      return s;
   }
   
   /**
    * Returns the node previous to the one specified.
    * @param n The node whose previous one will be returned.
    * @return The node previous to the one specified.
    */ 
   private Node previous( Node n) 
   {
      Node tmp = head;
      
      while ( tmp.next != n)
      {
         tmp = tmp.next;
      }
      return tmp;
   }
   
   /**
    * Returns the node next to the one specified.
    * @param n The node whose next one will be returned.
    * @return The node next to the one specified.
    */ 
   private Node next( Node n)
   {
      return n.next;
   }
   
   /**
    * Returns the last node of the list.
    * @return The last node of the list.
    */ 
   private Node tail()
   {
      Node tmp = head;
      
      if ( head != null)
      {
         while ( tmp.next != null)
         {
            tmp = tmp.next;
         }
      }
      return tmp;
   }
   
   // Given two lists, a & b, return a new list that contains
   // only those elements of a and b, that are not on both lists.  
   //
   // For example, if a is { "A", "D", "C" } & b is { "K", "B", "A", "C", "R" }
   // calling List.merger( a, b) might return { "D", "K", "B", "R" } 
   // or { "B", "D", "K", "R" } ~the order of the elements doesn't matter.
   //  
   // You can assume the input lists do not themselves contain duplicate elements, 
   // that is, { "A", "D", "C" } is ok, but { "A", "D", "D" } is not
   // since "D" appears twice.
   // 
   public static List merger( List a, List b)
   {
      List merged = new List();
      
      Node tmp = a.head;
      
      while ( tmp != null)
      {
         if ( ! b.contains( tmp.data))
         {
            merged.addToTail( tmp.data);
         }
         tmp = tmp.next;
      }
      
      tmp = b.head;
      
      while ( tmp!= null)
      {
         if ( ! a.contains( tmp.data))
         {
            merged.addToTail( tmp.data);
         }
         tmp = tmp.next;
      }
      return merged;
   }
   
   /**
    * Creates a list containing the values within the String[] in order.
    * @param strings The String[] containing the values to be added to the list.
    * @return A list containing the values within strings in order.
    */ 
   public static List createFrom( String[] strings)
   {
      List list = new List();
      
      for ( int i = 0; i < strings.length; i++)
      {
         list.addToTail( strings[i]);
      }
      return list;
   }
   
   /**
    * Creates a list containing the characters within the String in order.
    * @param string The String whose characters will be added to the list.
    * @return A list containing the characters within the String in order.
    */ 
   public static List createFrom( String string)
   {
      List list = new List();
      
      for ( int i = 0; i < string.length(); i++)
      {
         list.addToTail( string.charAt(i) + "");
      }
      return list;
   }
   
   /**
   * Private inner class Node that holds a String and a reference to the next Node within the List. 
   * @author Alp �neri
   * @version 6.5.19
   */ 
   private class Node 
   {
      String data; 
      Node next;
      
      public Node( String data, Node next) 
      {
         this.data = data; 
         this.next = next; 
      }
   }
}