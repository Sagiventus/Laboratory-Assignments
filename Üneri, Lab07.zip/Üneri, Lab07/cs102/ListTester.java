package cs102;
import junit.framework.TestCase;
import cs102.ds.List;

/**
 * JUnit test class to test the List class.
 * @author Alp �neri
 * @version 6.5.19
 */
public class ListTester extends TestCase 
{
   // properties
   List list;
   
   protected void setUp()
   {
      list = new List();
   }
   
   public void testIsEmpty() 
   {        
      assertTrue( "isEmpty is not working properly.", list.isEmpty());
      list.addToTail( "alpha");
      list.addToTail( "bravo");
      list.addToTail( "charlie");
      assertTrue( "isEmpty is not working properly.", !list.isEmpty());
   }
   
   public void testAdd()
   {
      list.addToTail( "alpha");
      list.addToTail( "bravo");
      list.addToTail( "charlie");
      
      assertTrue( "addToHead or addToTail is not working properly.", list.toString().equals( "alpha, bravo, charlie"));
   }
   
   public void testRemoveFromHead()
   {
      list.addToTail( "alpha");
      list.addToTail( "bravo");
      
      list.removeFromHead();
      
      assertTrue( "removeFromHead() is not working properly.", list.toString().equals( "bravo"));
   }
   
   public void testGetData()
   {
      list.addToTail( "alpha");
      list.addToTail( "bravo");
      list.addToTail( "charlie");
      
      assertTrue( "getData( int i) is not working properly.", list.getData(0) == "alpha");
      assertTrue( "getData( int i) is not working properly.", list.getData(1) == "bravo");
      assertTrue( "getData( int i) is not working properly.", list.getData(2) == "charlie");
   }
   
   public void testContains()
   {
      list.addToHead( "alpha");
      
      assertTrue( "contains( String s) is not working properly.", list.contains( "alpha") );
      assertTrue( "contains( String s) is not working properly.", !list.contains( "bravo") );
   }
   
   public void testIsOrdered()
   {
      list.addToTail( "alpha");
      list.addToTail( "bravo");
      
      assertTrue( "isOrdered() is not working properly.", list.isOrdered() );
      
      list.addToHead("charlie");
      assertTrue( "isOrdered() is not working properly.", !list.isOrdered() );
   }
   
   public void testCreateFrom()
   {
      String[] strings = { "alpha", "bravo", "charlie"};
      List arrayList = List.createFrom( strings);
      
      for ( int i = 0; i < strings.length; i++)
      {
         assertTrue( "createFrom(String[] strings) is not working properly.", arrayList.getData(i).equals( strings[i]));
      }

      String string = "alpha";
      List stringList = List.createFrom( string);
      
      for ( int i = 0; i < string.length(); i++)
      {
         assertTrue( "createFrom(String string) is not working properly.", stringList.getData(i).equals( "" + string.charAt(i)));
      }
      
   }
   
   public void testMerger()
   {
      List a = new List(); 
      a.addToTail( "alpha");
      a.addToTail( "bravo");
      a.addToTail( "charlie");
      
      List b = new List();
      b.addToTail( "alpha");
      b.addToTail( "delta");
      b.addToTail( "echo");
      
      List merged = new List();
      merged = merged.merger( a, b);
      
      assertTrue( "merger() is not working properly.", !merged.contains( "alpha"));
   }
   
}
