import java.util.Scanner;
import book.LibraryBook;

/**
 * Tests the LibraryBook class. 
 * @author Alp �neri
 * @version 04.12.18
 */ 
public class TestLibraryBook
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      LibraryBook book1;
      LibraryBook book2;

      // program code
      System.out.println( "Start...");
      
      //creating two books
      book1 = new LibraryBook( "Lord of the Flies", "William Golding");
      book2 = new LibraryBook( "What I Talk About When I Talk About Running", "Haruki Murakami");

      //printing the two objects
      System.out.println( book1.toString());
      System.out.println( book2.toString());
      
      //formatting
      System.out.println();
      System.out.println( "Loaning Lord of the Flies");
      
      //loaning the first book
      book1.loanBook( "01.11.19");
      System.out.println( book1.toString());
      System.out.println( "The book is on loan: " + book1.onLoan());
      
      //formatting
      System.out.println();
      System.out.println( "Returning Lord of the Flies");
      
      //returning the first book
      book1.returnBook();
      System.out.println( book1.toString());
      System.out.println( "The book is on loan: " + book1.onLoan());
      
      System.out.println( "End.");
   }

}