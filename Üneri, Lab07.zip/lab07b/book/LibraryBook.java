package book;

/**
 * @author Alp �neri
 * @version 04.12.18
 */
public class LibraryBook 
{
   // properties
   private String title;
   private String author;
   private String dueDate;
   private int timesLoaned;
   private boolean onLoan;

   // constructors
   public LibraryBook( String theTitle, String theAuthor)
   {
      title = theTitle;
      author = theAuthor;
      dueDate = "";
      timesLoaned = 0;
      onLoan = false;
   }
   
   // methods
   
   /**
   * Returns the object in string format. 
   * @return The object in string format
   */
   public String toString()
   {
      return "The book " + title + " by " + author + " has due date " + dueDate + 
         " and has been loaned " + timesLoaned + " times.";
   }
   
   /**
   * Loans the book: changes the due date, sets onLoan to true, and increments times loaned.
   * @param newDueDate The new due date
   */
   public void loanBook( String newDueDate)
   {
      dueDate = newDueDate;
      timesLoaned++;
      onLoan = true;
   }
   
   /**
   * Returns the book: resets due date and sets onLoan to false.
   */
   public void returnBook()
   {
      dueDate = "";
      onLoan = false;
   }
   
   /**
   * Return how many times the book has been loaned.
   * @return How many times the book has been loaned
   */
   public int getTimesLoaned()
   {
      return timesLoaned;
   }
   
   /**
   * Returns true if book is on loan and false if it is not.
   */
   public boolean onLoan()
   {
      return onLoan;
   }

}