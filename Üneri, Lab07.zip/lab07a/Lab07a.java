import java.util.Scanner;

/**
 * Old version of DiceGame 
 * @author Alp �neri
 * @version 04.12.18
 */ 
public class Lab07a
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      double throw1;
      double throw2;
      int count;
      boolean flag;

      // program code
      System.out.println( "Start...");
      
      //setting the variables to the appropriate value
      count = 0;
      flag = true;
      
      //mechanism similar to sentinel controlled input
      throw1 = (int) (Math.random() * 6 + 1);
      throw2 = (int) (Math.random() * 6 + 1);
      
      while( flag)
      {
         throw1 = (int) (Math.random() * 6 + 1);
         throw2 = (int) (Math.random() * 6 + 1);
         count++;
         
         //printing the rolls for diagnosis
         System.out.println( "DIAG: " + throw1 + "   " + throw2);
         
         //checking if two sixes were rolled
         if ( throw1 == 6 && throw2 == 6)
            flag = false;
      }


      System.out.println( "The dice was rolled " + count + " times.");
      System.out.println( "End.");
      
      /*stimulating more than two dies is quite diffucult as I would need to make a separate variable
       *everytime I wanted to add another die, and as the if statement checking for the wanted value
       *would get extremely long, even if this was part of a reusable method thing inevitably end up
       *getting hairy
       */
   }

}