import java.util.Scanner;
import gambling.Die;

/**
 * Tests the die class. 
 * @author Alp �neri
 * @version 04.12.18
 */ 
public class TestDie
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      Die test1;
      Die test2;

      // program code
      System.out.println( "Start...");
      
      //creating two dies
      test1 = new Die();
      test2 = new Die();
      
      //testing the first die
      System.out.println( "DIAG: " + test1.roll());
      System.out.println( "DIAG: " + test1.getFaceValue());
      System.out.println( "DIAG: " + test1);
      System.out.println( "DIAG: " + test1.toString());
      
      //testing the second die
      System.out.println( "DIAG: " + test2.roll());
      System.out.println( "DIAG: " + test2.getFaceValue());
      System.out.println( "DIAG: " + test2);
      System.out.println( "DIAG: " + test2.toString());


      System.out.println( "End.");
   }

}