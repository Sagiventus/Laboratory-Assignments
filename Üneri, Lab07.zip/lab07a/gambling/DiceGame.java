package gambling;

/**
 * @author Alp �neri
 * @version 04.12.18
 */
public class DiceGame
{
   // properties
   private Dice test;

   // constructors
   public DiceGame()
   {
      test = new Dice();
   }
   
   // methods
   
   /**
   * Rolls a dice continuosly until double sixes are rolled, returns how many rolls it took.
   * @return How many rolls it took to roll double sixes
   */
   public int play()
   {
      boolean flag = true;
      int count;
      
      count = 0;
      test.rollTogether();
      
      while ( flag)
      {
         count++;
         
         if ( test.rollTogether() == 12)
            flag = false;
      }
      
      return count;
   }

}