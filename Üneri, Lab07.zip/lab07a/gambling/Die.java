package gambling;

/**
 * @author Alp �neri
 * @version 04.12.18
 */
public class Die 
{
   // properties
   private int faceValue;

   // constructors
   public Die()
   {
      faceValue = 0;
   }

   // methods
   
   /**
   * Rolls the die and returns its face value.
   * @return The face value of the die
   */
   public int roll()
   {
      faceValue = (int) (Math.random() * 6 + 1);
      return faceValue;
   }
   
   /**
   * Gets the face value of the die.
   * @return The face value of the die
   */
   public int getFaceValue()
   {
      return faceValue;
   }
   
   /**
   * Returns the die in string format.
   * @return The die in string format
   */
   public String toString()
   {
      return "The die has face value " + faceValue + ".";
   }
   
}