package gambling;

/**
 * @author Alp �neri
 * @version 04.12.18
 */
public class Dice 
{
   // properties
   private Die test1;
   private Die test2;

   // constructors
   public Dice()
   {
      test1 = new Die();
      test2 = new Die();
   }
   
   // methods
   /**
   * Rolls the two dies and returns the sum of the two face values.
   * @return The sum of the two face values
   */
   public int rollTogether()
   {
      return test1.roll() + test2.roll();
   }
   
   /**
   * Gets the face value of the first die.
   * @return The face value of the first die
   */
   public int getDie1FaceValue()
   {
      return test1.getFaceValue();
   }

   /**
   * Gets the face value of the second die.
   * @return The face value of the second die
   */
   public int getDie2FaceValue()
   {
      return test2.getFaceValue();
   }
   
   /**
   * Returns the sum of the two face values.
   * @return The sum of the two face values
   */
   public int getDiceTotal()
   {
      return test1.getFaceValue() + test2.getFaceValue();
   }
   
   /**
   * Returns the dice in string format.
   * @return The dice in string format
   */
   public String toString()
   {
      return "The first die has face value " + test1.getFaceValue() + " and the second die has face value " + test2.getFaceValue() + ".";
   }
   
}