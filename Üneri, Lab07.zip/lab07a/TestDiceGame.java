import java.util.Scanner;
import gambling.DiceGame;

/**
 * Tests the DiceGame class. 
 * @author Alp �neri
 * @version 04.12.18
 */ 
public class TestDiceGame
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants
      DiceGame test;

      // variables

      // program code
      System.out.println( "Start...");
      
      test = new DiceGame();
      System.out.println( "The dice has to be rolled " + test.play() + " times to get double sixes.");

      System.out.println( "End.");
   }

}