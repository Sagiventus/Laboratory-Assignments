import java.util.Scanner;
import gambling.Dice;

/**
 * Tests the dice class. 
 * @author Alp �neri
 * @version 06.12.18
 */ 
public class TestDice
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      Dice test;

      // program code
      System.out.println( "Start...");
      
      test = new Dice();

      System.out.println( "DIAG: " + test.rollTogether());
      System.out.println( "DIAG: " + test.rollTogether());
      System.out.println( "DIAG: " + test.getDie1FaceValue());
      System.out.println( "DIAG: " + test.getDie2FaceValue());
      System.out.println( "DIAG: " + test.getDiceTotal());
      System.out.println( "DIAG: " + test);

      System.out.println( "End.");
   }

}