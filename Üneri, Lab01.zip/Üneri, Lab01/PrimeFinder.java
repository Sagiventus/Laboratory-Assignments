import intbag.IntBag;

/**
 * Finds the first n prime numbers. 
 * @author Alp �neri
 * @version 16.2.19
 */ 
public class PrimeFinder
{
   public static void main( String[] args)
   {
      //constants
      final int LIMIT = 1000;
      
      // variables
      IntBag primes;
      int test;
      boolean flag;
      int valid;

      // program code
      System.out.println( "Start...");
      
      //initialize the variables
      primes = new IntBag( LIMIT);
      test = 3;
      flag = true;
      
      //add the first prime into primes
      primes.add(2);

      while( primes.getValid() < LIMIT)
      {
         //store valid in a variable in order to be able to get out of the for loop
         valid = primes.getValid();

         //check if test is prime
         for ( int i = 0; i < valid; i++)
         {
            if ( test % primes.get( i) == 0)
               flag = false;
         }
         
         //add test to primes if it is prime
         if ( flag)
            primes.add( test);
         
         //prepare to check the following number
         test++;
         flag = true;
      }
      
      //print out the primes
      System.out.println( "The first " + LIMIT + " primes are: ");
      System.out.println( primes);

      System.out.println( "End.");
   }

}