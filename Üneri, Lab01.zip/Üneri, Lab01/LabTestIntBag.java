import java.util.Scanner;
import intbag.IntBag;

/**
 * Tests the IntBag class
 * @author Alp �neri
 * @version 16.2.19
 */ 
public class LabTestIntBag
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // variables
      boolean flag;
      IntBag collection;
      int response;
      int response1;
      int response2;
      int test;

      // program code
      System.out.println( "Start...");
      
      //initializing variables
      flag = true;
      collection = new IntBag();
      test = -12345;
      
      do
      {
         //main interface
         System.out.println( "Please select an option.");
         System.out.println( "1. Create a new empty collection with a specified maximum capacity (any previous values are lost!).");
         System.out.println( "2. Read a set of positive values into the collection (use a negative value to indicate all the values have been entered.).");
         System.out.println( "3. Print the collection of values.");
         System.out.println( "4. Add a value to the collection of values at a specified location.");
         System.out.println( "5. Remove the value at a specified location from the collection of values.");
         System.out.println( "6. Read a single test value.");
         System.out.println( "7. Compute the set of locations of the test value within the collection.");
         System.out.println( "8. Print the set of locations.");
         System.out.println( "9. Quit the program.");
         System.out.print( "Awaiting input: ");
         response = scan.nextInt();
         
         //create input
         if ( response == 1)
         {
            System.out.print( "Please enter the size of the collection you'd like to create: ");
            response1 = scan.nextInt();
            
            if ( response1 > 0)
            {
               collection = new IntBag( response1);
               System.out.println( "Collection successfully created.");
            }
            else
               System.out.println( "Cannot create a collection with 0 or less items!");
            
            //formatting
            System.out.println();
         }
         
         //read operator
         else if ( response == 2)
         {
            System.out.print( "Please enter the value to be added to the collection (negative to stop).");
            response1 = scan.nextInt();
            
            while( response1 >= 0)
            {
               if (collection.add( response1))
                  System.out.println( "Value successfully added to the collection.");
               else
                  System.out.println( "Value cannot be added, collection is full!");
               
               System.out.print( "Please enter the value to be added to the collection (negative to stop).");
               response1 = scan.nextInt();
            }
         }
         
         //print collection operator
         else if ( response == 3)
         {
            System.out.println( "The collection has values: ");
            System.out.println( collection);
            
            //formatting
            System.out.println();
         }
         
         //specific index add operator
         else if ( response == 4)
         {
            System.out.print( "Please enter the value you'd like added to the collection: ");
            response1 = scan.nextInt();
            
            System.out.print( "Please enter the index you'd like the value to be added to the collection at: ");
            response2 = scan.nextInt();
            
            if (collection.add( response1, response2))
               System.out.println( "Value successfully added to the collection.");
            else
               System.out.println( "Value cannot be added, index is out of bounds!");
            
            //formatting
            System.out.println();
         }
         
         //remove operator
         else if ( response == 5)
         {
            System.out.print( "Please enter the index of the value you'd like removed.");
            response1 = scan.nextInt();
            
            collection.remove( response1);
            System.out.println( "Value successfully removed.");
            
            //formatting
            System.out.println();
         }
         
         //test value operator
         else if ( response == 6)
         {
            System.out.print( "Please enter the test value: ");
            test = scan.nextInt();
            
            System.out.println( "Value successfully stored in memory.");
            
            //formatting
            System.out.println();
         }
         
         //search operator
         else if ( response == 7)
         {
            if ( test != -12345)
            {
               collection.findAll( test);
               System.out.println( "Found all indexes of the test value.");
            }
            else
               System.out.println( "No test value entered!");
            
            //formatting
            System.out.println();
         }
         
         //print locations operator
         else if ( response == 8)
         {
            if ( test != -12345)
               System.out.println( "The value " + test + " appears at the following indexes: " + collection.findAll( test) + ".");
            else
               System.out.println( "No test value entered!");
            
            //formatting
            System.out.println();
         }
         
         //quit operator
         else if ( response == 9)
         {
            flag = false;
         }
         
         //invalid input operator
         else
         {
            System.out.println( "Invalid input!");
         
            //formatting
            System.out.println();
         }
         
      } while ( flag);

      System.out.println( "End.");
   }

}