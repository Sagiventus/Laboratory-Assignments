import java.util.Scanner;

/**
 * inputs char and positive int, displays triangle formed of char with height int 
 * @author Alp �neri
 * @version 01.11.18
 */ 
public class lab04d
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      
      String ch;
      int width;
      int width1;
      int width2;
      int width3;

      // program code
      System.out.println( "Start...");
      
      //getting the char
      System.out.print( "Please enter a character.");
      ch = scan.next();
      
      //getting the int
      System.out.print( "Please enter a positive integer value.");
      width = scan.nextInt();
      
      //setting the values appropriately
      width1 = width;
      width2 = 1;
      width3 = 2;
      
      while ( width1 > 0)
      {
         while ( width2 > 0)
         {
            System.out.print( ch);
            width2 = width2 - 1;
         }
         System.out.println();
         width2 = width2 + width3;
         width1 = width1 - 1;
         width3 = width3 + 1;
      }     
      
      
      //second part
      double d;
      d = 0.1;
      
      //if while (d != 1 ) is entered as the condition, the program falls into
      //an infinite loop due to a discrepancy that results from the numbers
      //being stored in base 2, the program computes the value as 0.99999999
      //as opposed to 1.0, thus never stops
      while ( d < 1.0 )
      {
         System.out.println( d);
         d = d + 0.1;
      }
      System.out.println( d + " <- final value after loop!");


      System.out.println( "End.");
   }

}