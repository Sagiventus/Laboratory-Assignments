import java.util.Scanner;

/**
 * inputs 100 values, displays sum, count, average, max, min 
 * @author Alp �neri
 * @version 01.11.18
 */ 
public class lab04b
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants
      
      final int N = 100;

      // variables
      
      int count;
      int sum;
      int value;
      int average;
      int minimum;
      int maximum;

      // program code
      System.out.println( "Start...");
      
      //setting the values appropriately
      minimum = 99999999;
      maximum = 0;
      count = 0;
      sum = 0;
      
      //reading the values and determining sum, count, max, min
      while ( count < N)
      {
         value = scan.nextInt();
         count = count + 1;
         sum = sum + value;
         
         if ( value < minimum)
            minimum = value;
         
         if ( value > maximum)
            maximum = value;
      }
      
      //determining average
      average = sum / count;
      
      //printing out count, sum, average, max, min
      System.out.println( "The number of values entered is " + count + ".");
      System.out.println( "The sum of the values entered is " + sum + ".");
      System.out.println( "The average of the values entered is " + average + ".");
      System.out.println( "The largest value entered is " + maximum + ".");
      System.out.println( "The smallest value entered is " + minimum + ".");


      System.out.println( "End.");
   }

}