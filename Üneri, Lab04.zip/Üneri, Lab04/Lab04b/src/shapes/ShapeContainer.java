package shapes;
import java.util.ArrayList;
import shapes.*;
import java.util.Iterator;

/**
 * Class to contain an ArrayList of Shapes. 
 * @author Alp �neri
 * @version 10.3.19
 */ 
public class ShapeContainer
{
   // properties
   ArrayList<Circle> shapes;

   // constructors
   
   /**
    * Creates a new ShapeContainer object without any shapes in it.
    */ 
   public ShapeContainer()
   {
      shapes = new ArrayList<Circle>();
   }
   
   // methods
   
   /**
    * Adds the given shape to the collection.
    * @param s The shape to be added to the collection.
    */ 
   public void add( Circle s)
   {
      shapes.add( s);
   }
   
   /**
    * Removes the selected shapes.
    */ 
   public void removeSelected()
   {
      for ( int i = 0; i < shapes.size(); i++)
      {
         if ( shapes.get(i).getSelected())
         {
            shapes.remove(i);
         }
      }
   }
   
   public ShapeIterator iterator()
   {
      return new ShapeIterator();
   }
   
   public int size()
   {
      return shapes.size();
   }
   
   public int selectAllAt( int x, int y)
   {
      int number = 0;
      
      for ( int  i = 0; i < shapes.size(); i++)
      {
         if ( shapes.get(i).contains( x, y) != null)
         {
            shapes.get(i).setSelected( true);
            number++;
         }
      }
      //System.out.println( "b");
      return number;
   }
   
   public void selectAll()
   {
      for ( int i = 0; i < shapes.size(); i++)
      {
         shapes.get(i).setSelected( true);
      }
   }
   
   public class ShapeIterator implements Iterator
   {
      // properties
      int index;
      
      // constructors
      public ShapeIterator()
      {
         int index = 0;
      }
      
      // methods
      public Circle next()
      {
         if ( index < shapes.size())
         {
            Circle s = shapes.get( index);
            index++;
            return s;
         }
         return null;
      }
      
      public boolean hasNext()
      {
         if ( index < shapes.size())
         {
            return true;
         }
         return false;
      }
   }  
}