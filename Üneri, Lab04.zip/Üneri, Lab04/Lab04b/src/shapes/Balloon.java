package shapes;
import shapesinterface.*;

/**
 * Balloon class extends Circle, adds grow method. 
 * @author Alp �neri
 * @version 1.4.19
 */ 
public class Balloon extends Circle
{
   // constructors
   public Balloon()
   {
      super( 50);
      //super.randomLocation();
   }
   
   // methods
   public void grow()
   {
      radius++;
      
      if ( radius > 100)
      {
         radius = 0;
         super.randomLocation();
      }
   }
}