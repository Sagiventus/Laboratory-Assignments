package shapes;
import shapesinterface.*;
import java.awt.*;

/**
 * Circle class that extends the Shape class. 
 * @author Alp �neri
 * @version 10.3.19
 */ 
public class Circle extends Shape
{
   // properties
   int radius;
   boolean selected;
   
   // constructors
   
   /**
    * Creates a new Circle object centered at (0,0) with the given radius.
    * @param radius The radius of the circle to be created.
    */ 
   public Circle( int radius)
   {
      super();
      this.radius = radius;      
   }
   
   // methods
   
   /**
    * Returns the Circle if it contains the given point, null if it does not.
    * @return The Circle if it contains the given point, null if it does not.
    */ 
   public Shape contains( int xGiven, int yGiven)
   {
      int a = this.getX() - xGiven;
      int b = this.getY() - yGiven;
      double distance = Math.sqrt( a * a + b * b );
      
      if ( radius >= distance)
      {
         return this;
      }
      return null;
   }
   
   public void randomLocation()
   {
      xCoordinate = (int)(Math.random() * 750);
      yCoordinate = (int)(Math.random() * 750);
   }
   
   public void draw( Graphics g)
   {
      g.drawOval( xCoordinate-radius, yCoordinate-radius, radius*2, radius*2);
   }
}