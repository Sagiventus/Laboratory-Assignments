package shapesinterface;
import java.awt.*;

/**
 * Allows for a shape object to be drawable. 
 * @author Alp �neri
 * @version 31.3.19
 */ 
public interface Drawable
{
   // methods
   public abstract void draw( Graphics g);
}