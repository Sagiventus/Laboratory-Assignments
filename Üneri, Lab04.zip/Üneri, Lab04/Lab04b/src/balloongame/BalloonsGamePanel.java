package balloongame;
import shapes.*;
import shapesinterface.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Panel for BalloonGame
 * @author Alp �neri
 * @version 1.4.19
 */ 
public class BalloonsGamePanel extends JPanel
{
   // properties
   ShapeContainer balloons;
   Timer timer;
   int delay;
   int timeElapsed;
   JLabel pointsLabel;
   ActionListener taskPerformer;
   ShapeContainer.ShapeIterator iterator;
   ShapeContainer.ShapeIterator iterator2;
   int points;
   
   // constructors
   public BalloonsGamePanel()
   {
      balloons = new ShapeContainer();
      
      timeElapsed = 0;
      points = 0;
      pointsLabel = new JLabel( "Points: " + points);
      add( pointsLabel);
      
      for ( int j = 0; j < 25; j++)
      {
         Balloon b = new Balloon();
         balloons.add( b);
      }
      
      delay = 50;
      taskPerformer = new ActionListener()
      {
         public void actionPerformed( ActionEvent e)
         {
            iterator = balloons.iterator();
            
            for ( int i = 0; i < balloons.size(); i++)
            {
               ((Balloon) iterator.next()).grow();
            }
            
            balloons.removeSelected();
            repaint();
            
            timeElapsed = timeElapsed + 50;
            
            if ( balloons.size() < 15)
            {
               balloons.add( new Balloon());
            }
            
            if ( timeElapsed > 50 * 20 * 10)
            {
               timer.stop();
               int paneOption = new JOptionPane().showConfirmDialog( null, "Play Again?", "Game Over", JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
               
               if ( paneOption == JOptionPane.YES_OPTION)
               {
                  points = 0;
                  pointsLabel.setText( "Points: " + points);
                  timeElapsed = 0;
                  
                  balloons.selectAll();
                  balloons.removeSelected();
                  
                  for ( int j = 0; j < 25; j++)
                  {
                     Balloon b = new Balloon();
                     balloons.add( b);
                  }
                  
                  repaint();
                  timer.start();
               }
               else
               {
                  System.exit(0);
               }
            }
         }
      };
      
      addMouseListener( new MyMouseListener());
      setBackground( Color.YELLOW);
      setPreferredSize( new Dimension( 750, 750));
      
      timer = new Timer( delay, taskPerformer);
      timer.start();
   }
   
   // methods
   protected void paintComponent( Graphics g)
   {
      super.paintComponent( g);
      
      iterator2 = balloons.iterator();
      for ( int i = 0; i < balloons.size(); i++)
      {  
         ((Balloon) iterator2.next()).draw( g);
      }
   }

   public class MyMouseListener implements MouseListener
   {
      public void mouseClicked( MouseEvent e)
      {
         int k = balloons.selectAllAt( e.getX(), e.getY());
         if ( k >= 2)
         {
            points = points + k;
            pointsLabel.setText( "Points: " + points);
            repaint();
         }
      }
      public void mouseEntered( MouseEvent e){}
      public void mouseExited( MouseEvent e){}
      public void mousePressed( MouseEvent e){}
      public void mouseReleased( MouseEvent e){}
   }
}