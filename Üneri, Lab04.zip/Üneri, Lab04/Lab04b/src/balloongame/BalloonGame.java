package balloongame;
import javax.swing.*;
import java.awt.*;

/**
 * BaloonGame 
 * @author Alp �neri
 * @version 31.3.19
 */ 
public class BalloonGame
{
   public static void main( String[] args)
   {
      // variables
      JFrame gameFrame;
      BalloonsGamePanel panel;

      // program code
      gameFrame = new JFrame( "Balloons Game");
      panel = new BalloonsGamePanel();
      
      gameFrame.add( panel);
      gameFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
      gameFrame.pack();
      
      gameFrame.setVisible( true);
   }

}