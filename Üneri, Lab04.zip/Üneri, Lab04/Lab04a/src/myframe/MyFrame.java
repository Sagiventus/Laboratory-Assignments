package myframe;
import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Frame for Buttons Game.
 * @author Alp �neri
 * @version 31.3.19
 */ 
public class MyFrame extends JFrame
{
   // properties
   JFrame frame;
   JPanel buttonPanel;
   JPanel labelPanel;
   JLabel numberOfTries;
   ArrayList<JButton> buttonCollection;
   int tries;
   String triesText;
   int prize;

   // constructors
   public MyFrame()
   {
      //initialize the properties
      frame = new JFrame( "Buttons Game");
      buttonPanel = new JPanel( new GridLayout( 5, 5));
      labelPanel = new JPanel();
      buttonCollection = new ArrayList<JButton>();
      tries = 0;
      triesText = "Number of tries: " + tries;
      numberOfTries = new JLabel( triesText);
      prize = (int) (Math.random() * 25);
      
      //add 25 buttons, add a special listener to the one hiding the prize
      for ( int i = 1; i < 26; i++)
      {
         JButton button = new JButton( "" + i);
         buttonCollection.add( button);
         
         if ( i == prize)
         {
            button.addActionListener( new PrizeListener());
         }
         else
         {
            button.addActionListener( new ButtonListener());
         }
         
         buttonPanel.add( button);
      }
      
      labelPanel.add( numberOfTries);
      
      frame.add( labelPanel, BorderLayout.NORTH);
      frame.add( buttonPanel);
      
      frame.pack();

      frame.setVisible( true);
   }
   
   /**
    * Listener for an ordinary button, increments number of tries.
    * @author Alp �neri
    * @version 1.4.19
    */ 
   public class ButtonListener implements ActionListener
   {
      public void actionPerformed( ActionEvent e)
      {
         JButton sourceButton = (JButton) e.getSource();
         for ( int i = 0; i < buttonCollection.size(); i++)
         {
            if ( buttonCollection.get(i) == sourceButton)
            {
               buttonCollection.get(i).setVisible( false);
            }
         }
         tries++;
         triesText = "Number of tries: " + tries;

         numberOfTries.setText( triesText);
      }
   }
   
   /**
    * Listener for the button hiding the prize, shows number of attempts. 
    * @author Alp �neri
    * @version 31.3.19
    */ 
   public class PrizeListener implements ActionListener
   {
      public void actionPerformed( ActionEvent e)
      {
         JButton prizeButton = (JButton) e.getSource();
         for ( int i = 0; i < buttonCollection.size(); i++)
         {
            if ( buttonCollection.get(i) == prizeButton)
            {
               buttonCollection.get(i).setText( "Prize");
            }
            else
            {
               buttonCollection.get(i).setVisible( false);
            }
         }
         tries++;
         
         numberOfTries.setText( "You got it in " + tries + " attempts!");
      }
   }
}