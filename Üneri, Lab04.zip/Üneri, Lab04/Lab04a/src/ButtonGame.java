import myframe.*;

/**
 * Random button guessing game. 
 * @author Alp �neri
 * @version 31.3.19
 */ 
public class ButtonGame
{
   public static void main( String[] args)
   {
      // program code
      new MyFrame();
   }
}