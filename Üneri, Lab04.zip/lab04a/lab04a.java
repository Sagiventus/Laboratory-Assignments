import java.util.Scanner;

/**
 * inputs a positive integer, displays (0, n) etc.
 * @author Alp �neri
 * @version 01.11.18
 */ 
public class lab04a
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      
      int n;
      int printedInts;
      int x;
      double division;
      double y;
      

      // program code
      
      System.out.println( "Start...");
      
      System.out.print( "Please enter a positive integer value.");
      n = scan.nextInt();
      printedInts = 0;
      x = 0;
      
      
      //Checking if the value entered is positive or not
      if ( n < 0)
         System.out.println( "The integer value entered is not positive!");
      else
      {
        //first task 
        while ( printedInts < n)
         {
            System.out.print( x + " ");
            x = x + 1;
            printedInts = printedInts + 1;
         }
         
         //Resetting for the next task
         System.out.println();
         printedInts = 0;
         x = 0;
      
         //second task
         while ( printedInts < n)
         {
           System.out.print( x + " ");
           x = x + 1;
           
           if ( x % 5 == 0)
             System.out.println();
           
           printedInts = printedInts + 1;
         }
         
         //Resetting for the next task
         System.out.println();
         printedInts = 0;
         x = 0;
         
         //third task
         x = n;
         while ( printedInts <= n)
         {
            System.out.print( x + " ");
            x = x - 1;
            printedInts = printedInts + 1;
         }
         
         //Resetting for the next task
         System.out.println();
         printedInts = 0;
         x = 0;
         
         //fourth task
         x = -n;
         printedInts = -n;
         while ( printedInts <= n)
         {
            if ( x % 2 == 0)
               System.out.print( x + " ");
            x = x + 1;
            printedInts = printedInts + 1;
         }
         
         //Resetting for the next task
         System.out.println();
         printedInts = 0;
         x = 0;
         
         //fifth task
         while ( x <= n)
         {
            if ( x % 2 == 0)
            {
               System.out.print( x * x + " ");
               printedInts = printedInts + 1;
            }
            
            x = x + 1;
               
            if ( printedInts % 5 == 0)
               System.out.println();
         }
         
         //Resetting for the next task
         System.out.println();
         printedInts = 0;
         x = 0;
         
         //sixth task
         x = n;
         while ( x >= 3)
         {
            if ( x % 3 == 0)
               if ( x % 4 != 0)
               {
                  System.out.print( x + " ");
                  printedInts = printedInts + 1;
               }
            if ( x % 4 == 0)
               if (x % 3 != 0)
               {
                  System.out.print( x + " ");
                  printedInts = printedInts + 1;
               }
            
            x = x - 1;
            
            if ( printedInts % 5 == 0)
               System.out.println();
         }
         
         //Resetting for the next task
         System.out.println();
         printedInts = 0;
         x = 0;
         
         //seventh task
         x = 1;
         while ( x <= n)
         {
            if ( n % x == 0)
               System.out.print( x + " ");
            x = x + 1;
         }
         
         //Resetting for the next task
         System.out.println();
         printedInts = 0;
         x = 0;
         
         //eigthth task
         y = (double) n;  
         while ( y >= 1)
         {
            division = 1 / y;
            if ( division > 0.01)
            {
               System.out.printf( "%.2f", division);
               System.out.print( " ");
            }
            y = y - 1;
         }
      
      
      
      
      
      
      }
      System.out.println( "End.");
      }
   

}